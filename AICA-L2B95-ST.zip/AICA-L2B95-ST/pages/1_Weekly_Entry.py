import streamlit as st
from datetime import date, timedelta, datetime
import pandas as pd
from core.db import (
    SessionLocal, User, Team, UserTeam, Category, LeaveType, Holiday,
    WeeklyEntry, WeeklyLeave, WeeklyHours, Setting, log_audit
)
from core.auth import ROLE_ADMIN, ROLE_MANAGER, ROLE_TEAM_LEAD
from core.calendar import (
    get_monday, get_sunday, get_working_days_in_week, format_week_label
)
from core.calc import (
    LeaveRecord, HourRecord, calculate_week_utilization, get_burnout_tier
)
from core.ui_components import apply_custom_css

st.set_page_config(page_title="Weekly Entry — Utilization Tracker", page_icon="📝", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

current_user = st.session_state["user"]
session = SessionLocal()

try:
    # Fetch user details
    db_user = session.query(User).filter_by(id=current_user["id"]).first()
    if not db_user:
        st.error("User not found.")
        st.stop()

    std_daily_hours = float(session.query(Setting).filter_by(key="std_daily_hours").first().value or 7.5)
    categories = session.query(Category).filter_by(is_active=True).order_by(Category.sort_order).all()
    leave_types = session.query(LeaveType).all()
    user_location_id = db_user.location_id
    holidays = session.query(Holiday).filter_by(location_id=user_location_id).all()
    holiday_dates = {h.date for h in holidays}

    # Fetch user teams
    user_teams_query = session.query(Team).join(UserTeam).filter(
        UserTeam.user_id == db_user.id, Team.is_active == True
    ).all()
    if not user_teams_query:
        # Fallback to all active teams if none assigned
        user_teams_query = session.query(Team).filter_by(is_active=True).all()
    team_dict = {t.name: t.id for t in user_teams_query}

    st.markdown("""
    <div class="finance-header">
        <h1>📝 Weekly Hours & Leave Entry</h1>
        <p>Record your activity split across the 9 finance operational categories</p>
    </div>
    """, unsafe_allow_html=True)

    # 1. Week Selector
    today = date.today()
    current_monday = get_monday(today)
    
    # Generate range: last 12 weeks to next 2 weeks
    available_mondays = [current_monday + timedelta(weeks=i) for i in range(-12, 3)]
    week_options = {format_week_label(m): m for m in available_mondays}
    default_label = format_week_label(current_monday)

    col_wk1, col_wk2 = st.columns([2, 1])
    with col_wk1:
        selected_label = st.selectbox(
            "Select Week (Monday to Sunday):",
            list(week_options.keys()),
            index=list(week_options.keys()).index(default_label) if default_label in week_options else len(week_options)-3
        )
        selected_monday = week_options[selected_label]
        selected_sunday = selected_monday + timedelta(days=6)

    with col_wk2:
        st.caption(f"**Period Scope:** {selected_monday.strftime('%d %B %Y')} to {selected_sunday.strftime('%d %B %Y')}")
        working_days = get_working_days_in_week(selected_monday, holiday_dates)
        st.caption(f"**Standard Working Days in Week:** {working_days} days (7.5 hrs/day baseline)")

    # Check existing submission
    entry = session.query(WeeklyEntry).filter_by(user_id=db_user.id, week_start=selected_monday).first()
    is_locked = entry.locked if entry else False
    current_status = entry.status if entry else "Draft"

    if is_locked:
        st.error("🔒 This week has been locked by Administrator and cannot be modified.")

    # 2. Leave Section
    st.markdown("<div class='section-title'>🏖️ Leave & Absence Section</div>", unsafe_allow_html=True)
    
    col_l1, col_l2, col_l3 = st.columns([1.5, 1.2, 1.5])
    
    with col_l1:
        full_week_leave = st.checkbox("🌴 On leave the entire week (Auto-excludes from utilization)", value=False, disabled=is_locked)

    existing_leaves = {wl.leave_type_id: wl.days for wl in (entry.leaves if entry else [])}
    
    selected_leave_days = 0.0
    leaves_to_save = []

    if not full_week_leave:
        with col_l2:
            lt_options = {lt.name: lt for lt in leave_types}
            selected_lt_name = st.selectbox("Leave Type (if taking partial leave):", ["None"] + list(lt_options.keys()), disabled=is_locked)
        
        with col_l3:
            if selected_lt_name != "None":
                selected_lt = lt_options[selected_lt_name]
                init_days = existing_leaves.get(selected_lt.id, 1.0)
                leave_days_input = st.number_input("Days Taken (0.5 increments):", min_value=0.5, max_value=7.0, step=0.5, value=float(init_days), disabled=is_locked)
                selected_leave_days = leave_days_input
                leaves_to_save.append((selected_lt.id, selected_lt.name, leave_days_input, selected_lt.excluded_from_utilization))
    else:
        # Full week leave selected
        full_lt = next((lt for lt in leave_types if "Full-week" in lt.name), leave_types[0])
        leaves_to_save.append((full_lt.id, full_lt.name, float(working_days), True))
        selected_leave_days = float(working_days)

    # Calculate Available Hours live
    eff_work_days = max(0.0, float(working_days) - selected_leave_days) if not full_week_leave else 0.0
    available_hours = round(eff_work_days * std_daily_hours, 2)

    # 3. Hours Entry Grid
    st.markdown("<div class='section-title'>⏱️ Weekly Hours Allocation Grid</div>", unsafe_allow_html=True)
    st.info("💡 **Instructions**: Split your weekly logged hours across the 9 categories. Step = 0.25 hrs. Multiple team rows are permitted.")

    # Check copy last week's split button
    if st.button("📋 Copy Last Week's Hours Split", disabled=is_locked):
        last_week_monday = selected_monday - timedelta(weeks=1)
        last_entry = session.query(WeeklyEntry).filter_by(user_id=db_user.id, week_start=last_week_monday).first()
        if last_entry and last_entry.hours:
            st.session_state["copied_split"] = {(h.team_id, h.category_id): h.hours for h in last_entry.hours}
            st.success("Copied proportions from last week! Adjust numbers below as needed.")
        else:
            st.warning("No submission found for last week to copy.")

    copied_split = st.session_state.get("copied_split", {})

    # Existing saved hours
    existing_hours = {(h.team_id, h.category_id): h.hours for h in (entry.hours if entry else [])}

    # Number of team rows
    num_team_rows = st.number_input("Number of Teams / Project Splits to Log:", min_value=1, max_value=4, value=1, step=1, disabled=is_locked)

    hours_data_to_save = []
    total_logged_hours = 0.0

    for row_idx in range(int(num_team_rows)):
        st.markdown(f"**Row {row_idx + 1} Allocation:**")
        row_team_name = st.selectbox(
            f"Select Team for Row {row_idx + 1}:",
            list(team_dict.keys()),
            key=f"team_select_{row_idx}",
            disabled=is_locked
        )
        row_team_id = team_dict[row_team_name]

        cols = st.columns(9)
        row_hours_sum = 0.0
        for cat_idx, cat in enumerate(categories):
            with cols[cat_idx]:
                key = f"h_{row_idx}_{cat.code}"
                # Default value priority: session copy -> existing db -> 0.0
                def_val = copied_split.get((row_team_id, cat.id), existing_hours.get((row_team_id, cat.id), 0.0))
                val = st.number_input(
                    f"{cat.sort_order}. {cat.code}",
                    min_value=0.0,
                    max_value=120.0,
                    step=0.25,
                    value=float(def_val),
                    key=key,
                    help=f"{cat.name} ({cat.type})",
                    disabled=is_locked or full_week_leave
                )
                if val > 0:
                    hours_data_to_save.append((row_team_id, cat.id, val))
                    row_hours_sum += val
        
        st.caption(f"**Row {row_idx + 1} Total Hours:** `{row_hours_sum:.2f} hrs`")
        total_logged_hours += row_hours_sum
        st.markdown("---")

    # 4. Live Utilization Calculation & Prominent Card
    if full_week_leave or (selected_leave_days >= working_days and working_days > 0):
        live_util = None
        is_excluded = True
        status_banner = "ℹ️ **Week Excluded from Utilization Metrics** (Full-week Leave / Sabbatical / Maternity)"
    elif available_hours > 0:
        live_util = round((total_logged_hours / available_hours) * 100.0, 1)
        is_excluded = False
    else:
        live_util = 0.0
        is_excluded = False

    # Prominent Card Display
    c_card1, c_card2, c_card3, c_card4 = st.columns(4)
    with c_card1:
        st.metric("Standard Working Days", f"{working_days} days", f"7.5 hrs/day baseline")
    with c_card2:
        st.metric("Available Capacity", f"{available_hours:.2f} hrs", f"Leave taken: {selected_leave_days:.1f} days")
    with c_card3:
        st.metric("Total Logged Hours", f"{total_logged_hours:.2f} hrs", f"{len(hours_data_to_save)} items logged")
    with c_card4:
        if is_excluded:
            st.metric("Live Utilization %", "EXCLUDED", "Dropped from numerator & denominator")
        else:
            tier = get_burnout_tier(live_util)
            delta_label = f"Overload Tier: {tier}" if tier else ("Optimal" if live_util and live_util >= 85 else "Standard")
            st.metric("Live Utilization %", f"{live_util:.1f}%", delta_label)

    # CRITICAL NON-BLOCKING AMBER INFO BANNER ON > 100%
    if not is_excluded and live_util and live_util > 100.0:
        tier = get_burnout_tier(live_util)
        st.warning(f"⚠️ **Informational Notice**: Logged hours ({total_logged_hours:.2f} hrs) exceed available capacity ({available_hours:.2f} hrs) — **{live_util:.1f}% Utilization ({tier} Tier)**. Your entry is valid and will NOT be restricted.")

    # 5. Comment Section
    st.markdown("<div class='section-title'>💬 Weekly Commentary & Context</div>", unsafe_allow_html=True)
    existing_comment = entry.comment if entry and entry.comment else ""
    comment_text = st.text_area(
        "Optional comments (e.g. 'Year-end close support, statutory audit samples, SAP reconciliation catch-up'):",
        value=existing_comment,
        disabled=is_locked
    )

    # 6. Action Buttons: Save as Draft & Submit
    if not is_locked:
        col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 2])
        
        with col_btn1:
            save_draft = st.button("💾 Save as Draft", use_container_width=True)
        with col_btn2:
            submit_hours = st.button("🚀 Submit Hours", type="primary", use_container_width=True)

        if save_draft or submit_hours:
            new_status = "Submitted" if submit_hours else "Draft"
            
            # Upsert Weekly Entry
            if not entry:
                entry = WeeklyEntry(
                    user_id=db_user.id,
                    week_start=selected_monday,
                    status=new_status,
                    comment=comment_text,
                    submitted_at=datetime.utcnow() if submit_hours else None,
                    locked=False
                )
                session.add(entry)
                session.flush()
                log_audit(session, db_user.id, f"CREATE_{new_status.upper()}", "weekly_entries", entry.id, None, str(selected_monday))
            else:
                old_val = f"Status: {entry.status}, Total: {total_logged_hours}"
                entry.status = new_status
                entry.comment = comment_text
                if submit_hours:
                    entry.submitted_at = datetime.utcnow()
                log_audit(session, db_user.id, f"UPDATE_{new_status.upper()}", "weekly_entries", entry.id, old_val, str(total_logged_hours))

            # Delete old leaves and insert new
            session.query(WeeklyLeave).filter_by(entry_id=entry.id).delete()
            for lt_id, lt_name, l_days, is_exc in leaves_to_save:
                session.add(WeeklyLeave(entry_id=entry.id, leave_type_id=lt_id, days=l_days))

            # Delete old hours and insert new
            session.query(WeeklyHours).filter_by(entry_id=entry.id).delete()
            for r_tid, r_cid, r_hrs in hours_data_to_save:
                session.add(WeeklyHours(entry_id=entry.id, team_id=r_tid, category_id=r_cid, hours=r_hrs))

            session.commit()
            st.success(f"✅ Hours successfully saved with status: **{new_status}**!")
            st.rerun()

    # 7. Reminder Panel for Managers & Team Leads
    if current_user["role"] in [ROLE_TEAM_LEAD, ROLE_MANAGER, ROLE_ADMIN]:
        st.markdown("<div class='section-title'>🔔 Team Submission Compliance Reminder Panel</div>", unsafe_allow_html=True)
        with st.expander(f"Review Pending Submissions for {format_week_label(selected_monday)}", expanded=False):
            # Find all employees in user's managed teams
            all_managed_users = session.query(User).filter(User.is_active == True, User.role == "Employee").all()
            missing_emps = []
            submitted_emps = []

            for mu in all_managed_users:
                sub = session.query(WeeklyEntry).filter_by(user_id=mu.id, week_start=selected_monday).first()
                if not sub or sub.status != "Submitted":
                    missing_emps.append({"Employee ID": mu.emp_id, "Name": mu.name, "Email": mu.email, "Status": sub.status if sub else "Not Started"})
                else:
                    submitted_emps.append({"Employee ID": mu.emp_id, "Name": mu.name, "Submitted At": sub.submitted_at})

            col_m1, col_m2 = st.columns(2)
            with col_m1:
                st.markdown(f"**🔴 Missing Submissions ({len(missing_emps)} employees):**")
                if missing_emps:
                    st.dataframe(pd.DataFrame(missing_emps), use_container_width=True)
                else:
                    st.success("🎉 All team members have submitted for this week!")

            with col_m2:
                st.markdown(f"**🟢 Completed Submissions ({len(submitted_emps)} employees):**")
                if submitted_emps:
                    st.dataframe(pd.DataFrame(submitted_emps), use_container_width=True)

finally:
    session.close()
