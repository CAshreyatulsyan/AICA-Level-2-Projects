import streamlit as st
from datetime import date, timedelta
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from core.db import SessionLocal, User, Team, UserTeam, Setting
from core.auth import ROLE_ADMIN, ROLE_DIRECTOR, ROLE_MANAGER, ROLE_TEAM_LEAD
from core.data_service import fetch_and_calculate_telemetry
from core.calendar import format_week_label, get_weeks_for_year
from core.ui_components import apply_custom_css, render_kpi_card

st.set_page_config(page_title="Team View — Utilization Tracker", page_icon="👥", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

current_user = st.session_state["user"]
session = SessionLocal()

try:
    st.markdown("""
    <div class="finance-header">
        <h1>👥 Team Capacity & Operational View</h1>
        <p>Operational workload distribution, member utilization, and team category allocations</p>
    </div>
    """, unsafe_allow_html=True)

    # Fetch accessible teams
    if current_user["role"] in [ROLE_ADMIN, ROLE_DIRECTOR]:
        accessible_teams = session.query(Team).filter_by(is_active=True).order_by(Team.name).all()
    else:
        # Team Lead / Manager / Employee: user's teams
        accessible_teams = session.query(Team).join(UserTeam).filter(
            UserTeam.user_id == current_user["id"], Team.is_active == True
        ).all()
        if not accessible_teams:
            accessible_teams = session.query(Team).filter_by(is_active=True).all()

    team_options = {t.name: t.id for t in accessible_teams}

    col_t1, col_t2, col_t3 = st.columns([1.5, 1, 1])
    with col_t1:
        sel_team_name = st.selectbox("Select Team:", list(team_options.keys()), index=0)
        selected_team_id = team_options[sel_team_name]
    with col_t2:
        sel_year = st.selectbox("Year:", ["2026", "2025"], index=0)
    with col_t3:
        all_weeks = get_weeks_for_year(sel_year)
        week_labels = [format_week_label(w) for w in all_weeks]
        sel_week_lbl = st.selectbox("Focus Week:", ["All Weeks (YTD)"] + week_labels, index=0)

    start_w = None
    end_w = None
    if sel_week_lbl != "All Weeks (YTD)":
        w_idx = week_labels.index(sel_week_lbl)
        start_w = all_weeks[w_idx]
        end_w = all_weeks[w_idx]

    telemetry = fetch_and_calculate_telemetry(
        session=session,
        year_str=sel_year,
        team_ids=[selected_team_id],
        start_week=start_w,
        end_week=end_w
    )

    agg = telemetry["aggregated"]
    users_sum = telemetry["user_summaries"]
    all_cats = telemetry["all_cats"]

    # Team KPIs
    k1, k2, k3, k4, k5 = st.columns(5)
    with k1:
        u_pct = f"{agg['utilization_pct']:.1f}%" if agg['utilization_pct'] is not None else "N/A"
        render_kpi_card("Team Utilization", u_pct, f"Target: {agg['target_util_pct']:.0f}%")
    with k2:
        render_kpi_card("Logged Capacity", f"{agg['total_logged_hours']:,.1f} hrs", f"Avail: {agg['total_available_hours']:,.1f} hrs")
    with k3:
        render_kpi_card("Capacity Gap", f"{agg['capacity_gap']:+,.1f} hrs", "Overload if negative")
    with k4:
        render_kpi_card("Active Members", f"{len(users_sum)}", "In selected team")
    with k5:
        render_kpi_card("Burnout Weeks", f"{agg['burnout_weeks_count']}", f"Threshold > 100%")

    # Member Workload Table
    st.markdown("<div class='section-title'>📊 Team Member Performance & Capacity Table</div>", unsafe_allow_html=True)
    
    member_rows = []
    for u in users_sum:
        u_pct_str = f"{u['utilization_pct']:.1f}%" if u['utilization_pct'] is not None else "-"
        member_rows.append({
            "Employee ID": u["emp_id"],
            "Name": u["name"],
            "Available Hours": f"{u['available_hours']:.1f}",
            "Logged Hours": f"{u['logged_hours']:.1f}",
            "Utilization %": u_pct_str,
            "Top Category": u["top_category"],
            "Burnout Weeks": u["burnout_weeks_count"],
            "Max Overload Streak": f"{u['max_burnout_streak']} wks",
            "Peak Utilization": f"{u['peak_utilization']:.1f}%",
            "Submission Compliance": f"{u['compliance_pct']:.0f}%"
        })

    df_members = pd.DataFrame(member_rows)
    st.dataframe(df_members, use_container_width=True, hide_index=True)

    # Visualizations: Utilization by Member and Category Split
    c_chart1, c_chart2 = st.columns(2)
    
    with c_chart1:
        st.markdown("**Member Utilization vs Target Band (85%)**")
        df_mem_chart = pd.DataFrame([u for u in users_sum if u['utilization_pct'] is not None])
        if not df_mem_chart.empty:
            fig_mem = px.bar(
                df_mem_chart,
                x="name",
                y="utilization_pct",
                text="utilization_pct",
                color="utilization_pct",
                color_continuous_scale=["#EF4444", "#F59E0B", "#10B981", "#881337"],
                range_color=[60, 120]
            )
            fig_mem.add_hline(y=85.0, line_dash="dash", line_color="#10B981", annotation_text="Target 85%")
            fig_mem.add_hline(y=100.0, line_dash="dot", line_color="#EF4444", annotation_text="Overload 100%")
            fig_mem.update_layout(height=350, margin=dict(l=20, r=20, t=30, b=40), xaxis_title="Employee", yaxis_title="Utilization %")
            st.plotly_chart(fig_mem, use_container_width=True)

    with c_chart2:
        st.markdown("**Team Activity Mix % (Donut)**")
        cat_mix_data = []
        for cid, cdata in agg["category_metrics"].items():
            cat = all_cats.get(cid)
            if cat and cdata["hours"] > 0:
                cat_mix_data.append({
                    "Category": f"{cat.sort_order}. {cat.code}",
                    "Hours": cdata["hours"],
                    "Color": cat.color
                })
        if cat_mix_data:
            df_donut = pd.DataFrame(cat_mix_data)
            fig_donut = px.pie(
                df_donut,
                names="Category",
                values="Hours",
                hole=0.45,
                color="Category",
                color_discrete_map={row["Category"]: row["Color"] for _, row in df_donut.iterrows()}
            )
            fig_donut.update_layout(height=350, margin=dict(l=20, r=20, t=30, b=40))
            st.plotly_chart(fig_donut, use_container_width=True)

finally:
    session.close()
