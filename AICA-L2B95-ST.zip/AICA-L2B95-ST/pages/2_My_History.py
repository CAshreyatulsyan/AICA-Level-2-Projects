import streamlit as st
from datetime import date, timedelta
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from core.db import SessionLocal, User, Category, Setting
from core.data_service import fetch_and_calculate_telemetry
from core.calendar import get_fiscal_year, format_week_label
from core.ui_components import apply_custom_css, render_kpi_card

st.set_page_config(page_title="My History — Utilization Tracker", page_icon="📜", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

current_user = st.session_state["user"]
session = SessionLocal()

try:
    st.markdown("""
    <div class="finance-header">
        <h1>📜 My Personal Utilization History</h1>
        <p>Review your personal capacity metrics, historical logged hours, and category breakdown</p>
    </div>
    """, unsafe_allow_html=True)

    # Filter year
    col_y1, col_y2 = st.columns([1, 3])
    with col_y1:
        sel_year = st.selectbox("Select Year:", ["2026", "2025", "2024"], index=0)

    # Fetch data specifically for current user
    telemetry = fetch_and_calculate_telemetry(
        session=session,
        year_str=sel_year,
        fy_basis="CALENDAR",
        user_ids=[current_user["id"]]
    )

    agg = telemetry["aggregated"]
    weekly_res = telemetry["weekly_results"]
    all_cats = telemetry["all_cats"]

    # Personal KPIs
    k1, k2, k3, k4, k5 = st.columns(5)
    with k1:
        u_pct = f"{agg['utilization_pct']:.1f}%" if agg['utilization_pct'] is not None else "N/A"
        render_kpi_card("Personal Util %", u_pct, f"Target: {agg['target_util_pct']:.0f}%")
    with k2:
        render_kpi_card("Total Logged", f"{agg['total_logged_hours']:,.1f} hrs", f"Avail: {agg['total_available_hours']:,.1f} hrs")
    with k3:
        render_kpi_card("Capacity Buffer", f"{agg['capacity_gap']:+,.1f} hrs", "Overload if negative")
    with k4:
        render_kpi_card("Overload Weeks", f"{agg['burnout_weeks_count']}", f"Max Streak: {agg['max_burnout_streak']} wks")
    with k5:
        render_kpi_card("Included Weeks", f"{agg['included_weeks_count']}", f"Excluded: {agg['excluded_weeks_count']}")

    st.markdown("<div class='section-title'>📈 Weekly Utilization Trend</div>", unsafe_allow_html=True)

    # Prepare DataFrame for trend chart
    trend_data = []
    for r in sorted(weekly_res, key=lambda x: x["week_start"]):
        trend_data.append({
            "Week": r["week_label"],
            "Week Start": r["week_start"],
            "Utilization %": r["utilization_pct"] if not r["is_excluded"] else None,
            "Logged Hours": r["logged_hours"],
            "Available Hours": r["available_hours"],
            "Status": r["status"],
            "Is Excluded": r["is_excluded"],
            "Exclusion Reason": r["exclusion_reason"]
        })

    df_trend = pd.DataFrame(trend_data)

    if not df_trend.empty:
        fig_trend = go.Figure()
        
        # Target Band (85%)
        fig_trend.add_trace(go.Scatter(
            x=df_trend["Week"],
            y=[85.0] * len(df_trend),
            mode="lines",
            name="Target (85%)",
            line=dict(color="#10B981", dash="dash", width=2)
        ))
        
        # Burnout Line (100%)
        fig_trend.add_trace(go.Scatter(
            x=df_trend["Week"],
            y=[100.0] * len(df_trend),
            mode="lines",
            name="Overload Threshold (100%)",
            line=dict(color="#EF4444", dash="dot", width=2)
        ))

        # Actual Utilization
        fig_trend.add_trace(go.Scatter(
            x=df_trend["Week"],
            y=df_trend["Utilization %"],
            mode="lines+markers",
            name="Your Utilization %",
            line=dict(color="#1E3A8A", width=3),
            marker=dict(size=7, color="#2563EB")
        ))

        fig_trend.update_layout(
            height=380,
            margin=dict(l=20, r=20, t=30, b=50),
            xaxis_title="Week",
            yaxis_title="Utilization %",
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig_trend, use_container_width=True)

    # Category Breakdown Stacked Bar Chart
    st.markdown("<div class='section-title'>📊 Category Hours Composition</div>", unsafe_allow_html=True)
    cat_records = []
    for r in sorted(weekly_res, key=lambda x: x["week_start"]):
        if r["hours_by_category"]:
            for cid, hrs in r["hours_by_category"].items():
                cat = all_cats.get(cid)
                if cat and hrs > 0:
                    cat_records.append({
                        "Week": r["week_label"],
                        "Category": f"{cat.sort_order}. {cat.name}",
                        "Color": cat.color,
                        "Hours": hrs
                    })

    if cat_records:
        df_cat = pd.DataFrame(cat_records)
        # Custom color map
        color_map = {row["Category"]: row["Color"] for _, row in df_cat.drop_duplicates(subset=["Category"]).iterrows()}
        fig_bar = px.bar(
            df_cat,
            x="Week",
            y="Hours",
            color="Category",
            color_discrete_map=color_map,
            barmode="stack",
            height=400
        )
        fig_bar.update_layout(
            margin=dict(l=20, r=20, t=30, b=50),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0)
        )
        st.plotly_chart(fig_bar, use_container_width=True)

    # Detailed Weekly Log Table
    st.markdown("<div class='section-title'>📋 Historical Weekly Records</div>", unsafe_allow_html=True)
    table_rows = []
    for r in sorted(weekly_res, key=lambda x: x["week_start"], reverse=True):
        u_val = f"{r['utilization_pct']:.1f}%" if r["utilization_pct"] is not None else ("EXCLUDED" if r["is_excluded"] else "-")
        table_rows.append({
            "Week": r["week_label"],
            "Logged Hours": f"{r['logged_hours']:.2f}",
            "Available Hours": f"{r['available_hours']:.2f}",
            "Utilization": u_val,
            "FTE": f"{r['fte']:.2f}",
            "Burnout Flag": f"⚠️ {r['burnout_tier']}" if r["is_burnout"] else "Optimal / Standard",
            "Submission Status": r["status"],
            "Comment": r["comment"] or "-"
        })

    df_table = pd.DataFrame(table_rows)
    st.dataframe(df_table, use_container_width=True, hide_index=True)

    # Download CSV
    csv_bytes = df_table.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download My History as CSV",
        data=csv_bytes,
        file_name=f"Utilization_History_{current_user['emp_id']}_{sel_year}.csv",
        mime="text/csv"
    )

finally:
    session.close()
