import streamlit as st
from datetime import date, datetime
import io
import pandas as pd
from core.db import SessionLocal, User, Team, UserTeam, Category, Location, WeeklyEntry, WeeklyHours, Setting
from core.auth import hash_password, ROLE_ADMIN, ROLE_DIRECTOR, ROLE_MANAGER, ROLE_TEAM_LEAD
from core.data_service import fetch_and_calculate_telemetry
from core.export_excel import (
    create_utilization_excel_workbook,
    generate_blank_employee_import_template,
    generate_blank_hours_import_template
)
from core.export_pptx import create_director_presentation
from core.insights import generate_insights
from core.ui_components import apply_custom_css, render_sidebar_filters

st.set_page_config(page_title="Exports & Bulk Uploads — Utilization Tracker", page_icon="📥", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

session = SessionLocal()

try:
    st.markdown("""
    <div class="finance-header">
        <h1>📥 Enterprise Reporting & Data Hub</h1>
        <p>Generate multi-tab financial audit workbooks, executive PowerPoint decks, and execute bulk migrations</p>
    </div>
    """, unsafe_allow_html=True)

    tab_export, tab_templates, tab_bulk = st.tabs(["📊 Generate Master Exports", "📑 Download Blank Templates", "📤 Bulk Excel Uploads"])

    # Filters for Exports
    with tab_export:
        st.markdown("### 1. Download Master Utilization Workbook (8 Comprehensive Sheets)")
        st.caption("Includes: Summary, Raw_Data, Employee_Weekly, Employee_Monthly, Employee_Yearly, Team_Category_Matrix, Category_Analysis, Leave_Exclusions, and Exceptions.")

        filters = render_sidebar_filters(session, default_year="2026")

        if st.button("🚀 Build & Download Master Excel Workbook (.xlsx)", type="primary"):
            with st.spinner("Generating multi-tab financial model with conditional formatting..."):
                telemetry = fetch_and_calculate_telemetry(
                    session=session,
                    year_str=filters["year_str"],
                    fy_basis=filters["fy_basis"],
                    team_ids=filters["team_ids"],
                    user_ids=filters["user_ids"],
                    location_ids=filters["location_ids"],
                    category_ids=filters["category_ids"],
                    cat_type_filter=filters["cat_type_filter"],
                    start_week=filters["start_week"],
                    end_week=filters["end_week"]
                )

                agg = telemetry["aggregated"]
                weekly_res = telemetry["weekly_results"]
                user_sums = telemetry["user_summaries"]
                all_cats = telemetry["all_cats"]
                all_teams = telemetry["all_teams"]
                raw_records = telemetry["raw_records"]

                # 3. Employee_Weekly DF
                ew_records = []
                for r in weekly_res:
                    ew_records.append({
                        "Employee": f"{r['emp_name']} ({r['emp_id']})",
                        "Team": r["team_name"],
                        "Week": r["week_label"].split(" ")[0],
                        "Utilization %": r["utilization_pct"] if not r["is_excluded"] else "EXCLUDED"
                    })
                df_ew = pd.DataFrame(ew_records).pivot_table(index=["Employee", "Team"], columns="Week", values="Utilization %", aggfunc="first").reset_index() if ew_records else pd.DataFrame()

                # 4. Employee_Monthly & Yearly DF
                em_records = []
                for r in weekly_res:
                    em_records.append({
                        "Employee": f"{r['emp_name']} ({r['emp_id']})",
                        "Team": r["team_name"],
                        "Month": r["week_start"].strftime("%b %Y"),
                        "Logged": r["logged_hours"] if not r["is_excluded"] else 0.0,
                        "Available": r["available_hours"] if not r["is_excluded"] else 0.0
                    })
                if em_records:
                    df_em_raw = pd.DataFrame(em_records).groupby(["Employee", "Team", "Month"])[["Logged", "Available"]].sum().reset_index()
                    df_em_raw["Utilization %"] = (df_em_raw["Logged"] / df_em_raw["Available"]).round(3)
                    df_em = df_em_raw.pivot_table(index=["Employee", "Team"], columns="Month", values="Utilization %").reset_index()
                else:
                    df_em = pd.DataFrame()

                df_ey = pd.DataFrame([{
                    "Employee ID": u["emp_id"],
                    "Name": u["name"],
                    "Team": u["team"],
                    "Total Logged (Hrs)": u["logged_hours"],
                    "Total Available (Hrs)": u["available_hours"],
                    "Full Year Utilization %": (u["utilization_pct"] / 100.0) if u["utilization_pct"] else 0.0,
                    "Burnout Weeks": u["burnout_weeks_count"],
                    "Peak Utilization %": (u["peak_utilization"] / 100.0) if u["peak_utilization"] else 0.0
                } for u in user_sums])

                # 5. Team Category Matrix DF
                tc_records = []
                for r in raw_records:
                    if r["logged_hours"] > 0 and r["category"] != "-":
                        tc_records.append({"Team": r["team"], "Category": r["category"], "Hours": r["logged_hours"]})
                df_tc = pd.DataFrame(tc_records).pivot_table(index="Team", columns="Category", values="Hours", aggfunc="sum", fill_value=0.0).reset_index() if tc_records else pd.DataFrame()

                # 6. Category Analysis DF
                df_ca = pd.DataFrame([{
                    "Category": all_cats.get(cid).name if all_cats.get(cid) else f"Cat {cid}",
                    "Type": all_cats.get(cid).type if all_cats.get(cid) else "BAU",
                    "Logged Hours": cdata["hours"],
                    "Mix %": cdata["mix_pct"] / 100.0,
                    "Share of Available %": cdata["utilization_pct"] / 100.0
                } for cid, cdata in agg["category_metrics"].items()])

                # 7. Leave Exclusions DF
                df_le = pd.DataFrame([{
                    "Employee ID": r["emp_id"],
                    "Name": r["emp_name"],
                    "Week": r["week_label"],
                    "Status": "EXCLUDED",
                    "Exclusion Reason": r["exclusion_reason"],
                    "Hours Logged in Excluded Week": r["hours_in_excluded_week"]
                } for r in weekly_res if r["is_excluded"]])

                # 8. Exceptions DF
                df_ex = pd.DataFrame([{
                    "Employee": r["emp_name"],
                    "Team": r["team_name"],
                    "Week": r["week_label"],
                    "Exception Type": f"Burnout Overload ({r['burnout_tier']})" if r["is_burnout"] else ("Under-utilized (<70%)" if r["utilization_pct"] and r["utilization_pct"] < 70 else ("Missing Submission" if r["status"] == "Missing" else "Other")),
                    "Utilization %": f"{r['utilization_pct']:.1f}%" if r["utilization_pct"] is not None else "-"
                } for r in weekly_res if r["is_burnout"] or (r["utilization_pct"] and r["utilization_pct"] < 70) or r["status"] == "Missing"])

                excel_io = create_utilization_excel_workbook(
                    summary_data=agg,
                    raw_records=raw_records,
                    employee_weekly_df=df_ew,
                    employee_monthly_df=df_em,
                    employee_yearly_df=df_ey,
                    team_cat_matrix_df=df_tc,
                    cat_analysis_df=df_ca,
                    leave_exclusions_df=df_le,
                    exceptions_df=df_ex,
                    filters_info=filters["filters_summary"]
                )

                st.download_button(
                    label="💾 Click Here to Download Master Workbook (.xlsx)",
                    data=excel_io.getvalue(),
                    file_name=f"Finance_Utilization_Master_{filters['year_str']}_{datetime.now().strftime('%Y%m%d')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    type="primary"
                )

    with tab_templates:
        st.markdown("### 2. Standardized Excel Import Templates")
        st.caption("Use these pre-formatted sheets to bulk-import employees or back-load historical hours.")

        col_tp1, col_tp2 = st.columns(2)
        with col_tp1:
            st.markdown("#### 👥 Employee Master Template")
            st.write("Columns: Employee ID, Full Name, Email, Role, Primary Team, Secondary Team, Location, Join Date, Exit Date, Active.")
            emp_tp_io = generate_blank_employee_import_template()
            st.download_button(
                label="📥 Download Blank Employee Template (.xlsx)",
                data=emp_tp_io.getvalue(),
                file_name="Template_Employee_Master_Import.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

        with col_tp2:
            st.markdown("#### ⏱️ Historical Hours Template")
            st.write("Columns: Employee ID, Week Start Monday, Team Name, Category Code (CLOSE/REPORTING/RECON/INTERCO/AUDIT/CI_AUTO/GOVERNANCE/ADHOC/FPNA), Logged Hours.")
            hrs_tp_io = generate_blank_hours_import_template()
            st.download_button(
                label="📥 Download Blank Hours Template (.xlsx)",
                data=hrs_tp_io.getvalue(),
                file_name="Template_Historical_Hours_Upload.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

    with tab_bulk:
        st.markdown("### 3. Bulk Upload & Data Ingestion")
        upload_choice = st.radio("Select Ingestion Target:", ["Bulk Upload Employees", "Bulk Upload Historical Hours"], horizontal=True)

        if upload_choice == "Bulk Upload Employees":
            emp_file = st.file_uploader("Upload Completed Employee Excel File (.xlsx)", type=["xlsx"])
            if emp_file and st.button("Process Employee Import", type="primary"):
                try:
                    df_upload = pd.read_excel(emp_file)
                    loc_map = {l.name: l.id for l in session.query(Location).all()}
                    team_map = {t.name: t.id for t in session.query(Team).all()}
                    
                    created_cnt = 0
                    errors = []

                    for idx, row in df_upload.iterrows():
                        emp_id = str(row.get("Employee ID *", "")).strip()
                        name = str(row.get("Full Name *", "")).strip()
                        email = str(row.get("Email *", "")).strip()
                        role = str(row.get("Role (Employee/Team Lead/Manager/Director/Admin) *", "Employee")).strip()
                        pri_team = str(row.get("Primary Team Name *", "")).strip()
                        loc_name = str(row.get("Location (e.g. India - Gurugram) *", "")).strip()

                        if not emp_id or not name or not email:
                            errors.append(f"Row {idx+2}: Missing mandatory Employee ID, Name, or Email.")
                            continue

                        # Check existing
                        existing = session.query(User).filter_by(emp_id=emp_id).first()
                        if existing:
                            errors.append(f"Row {idx+2}: Employee ID {emp_id} already exists. Skipped.")
                            continue

                        loc_id = loc_map.get(loc_name, list(loc_map.values())[0])
                        new_u = User(
                            emp_id=emp_id,
                            name=name,
                            email=email,
                            role=role,
                            password_hash=hash_password("welcome123"),
                            location_id=loc_id,
                            join_date=date.today(),
                            is_active=True,
                            must_change_pw=True
                        )
                        session.add(new_u)
                        session.flush()

                        # Team assignment
                        if pri_team in team_map:
                            session.add(UserTeam(user_id=new_u.id, team_id=team_map[pri_team], is_primary=True))

                        created_cnt += 1

                    session.commit()
                    st.success(f"🎉 Successfully imported {created_cnt} new employees! Default password set to 'welcome123' (forced change on first login).")
                    if errors:
                        with st.expander("Import Warnings / Errors", expanded=True):
                            for err in errors:
                                st.warning(err)
                except Exception as e:
                    session.rollback()
                    st.error(f"Error parsing upload file: {e}")

        else:
            hrs_file = st.file_uploader("Upload Historical Hours Excel File (.xlsx)", type=["xlsx"])
            if hrs_file and st.button("Process Hours Ingestion", type="primary"):
                try:
                    df_h_upload = pd.read_excel(hrs_file)
                    cats_by_code = {c.code: c.id for c in session.query(Category).all()}
                    teams_by_name = {t.name: t.id for t in session.query(Team).all()}
                    users_by_empid = {u.emp_id: u for u in session.query(User).all()}

                    uploaded_cnt = 0
                    h_errors = []

                    for idx, row in df_h_upload.iterrows():
                        empid = str(row.get("Employee ID *", "")).strip()
                        w_date_raw = row.get("Week Start Monday (YYYY-MM-DD) *")
                        t_name = str(row.get("Team Name *", "")).strip()
                        c_code = str(row.get("Category Code (CLOSE/REPORTING/RECON/INTERCO/AUDIT/CI_AUTO/GOVERNANCE/ADHOC/FPNA) *", "")).strip().upper()
                        hrs_val = float(row.get("Logged Hours *", 0.0))

                        u = users_by_empid.get(empid)
                        if not u:
                            h_errors.append(f"Row {idx+2}: Employee ID {empid} not found in system.")
                            continue

                        t_id = teams_by_name.get(t_name)
                        if not t_id:
                            h_errors.append(f"Row {idx+2}: Team {t_name} not recognized.")
                            continue

                        c_id = cats_by_code.get(c_code)
                        if not c_id:
                            h_errors.append(f"Row {idx+2}: Category code {c_code} invalid.")
                            continue

                        # Parse date
                        if isinstance(w_date_raw, str):
                            w_date = datetime.strptime(w_date_raw[:10], "%Y-%m-%d").date()
                        elif isinstance(w_date_raw, datetime):
                            w_date = w_date_raw.date()
                        else:
                            w_date = w_date_raw

                        # Ensure Monday
                        from core.calendar import get_monday
                        w_monday = get_monday(w_date)

                        # Find or create entry
                        entry = session.query(WeeklyEntry).filter_by(user_id=u.id, week_start=w_monday).first()
                        if not entry:
                            entry = WeeklyEntry(user_id=u.id, week_start=w_monday, status="Submitted", submitted_at=datetime.utcnow(), locked=False)
                            session.add(entry)
                            session.flush()

                        # Check existing hours row
                        wh = session.query(WeeklyHours).filter_by(entry_id=entry.id, team_id=t_id, category_id=c_id).first()
                        if wh:
                            wh.hours = hrs_val
                        else:
                            session.add(WeeklyHours(entry_id=entry.id, team_id=t_id, category_id=c_id, hours=hrs_val))

                        uploaded_cnt += 1

                    session.commit()
                    st.success(f"🎉 Successfully imported {uploaded_cnt} historical category hours records!")
                    if h_errors:
                        with st.expander("Ingestion Warnings", expanded=True):
                            for err in h_errors[:25]:
                                st.warning(err)
                except Exception as e:
                    session.rollback()
                    st.error(f"Error ingesting hours: {e}")

finally:
    session.close()
