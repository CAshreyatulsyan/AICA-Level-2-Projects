import streamlit as st
import os
import shutil
from datetime import datetime, date, timedelta
import pandas as pd
from core.db import (
    SessionLocal, User, Team, UserTeam, Category, LeaveType, Holiday,
    Location, Setting, AuditLog, WeeklyEntry, DB_PATH, BASE_DIR
)
from core.auth import hash_password, ROLE_ADMIN
from core.seed_data import seed_demo_data, clear_demo_data
from core.ui_components import apply_custom_css

st.set_page_config(page_title="Administration — Utilization Tracker", page_icon="⚙️", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

current_user = st.session_state["user"]
if current_user["role"] != ROLE_ADMIN:
    st.error("⛔ Access Denied: You must have Administrator privileges to access this console.")
    st.stop()

session = SessionLocal()

try:
    st.markdown("""
    <div class="finance-header">
        <h1>⚙️ System Administration Console</h1>
        <p>Enterprise master data governance, calculation thresholds, lock policies, and backups</p>
    </div>
    """, unsafe_allow_html=True)

    tab_users, tab_teams, tab_rules, tab_holidays, tab_audit, tab_backup = st.tabs([
        "👥 Users & Teams", "🏢 Team Master", "⚙️ Calculation Rules & Targets",
        "📅 Holiday & Leave Master", "📜 Audit Log Viewer", "💾 Backups & Demo Data"
    ])

    # ==========================================
    # 1. USERS & TEAMS
    # ==========================================
    with tab_users:
        st.markdown("### User Management")
        all_users = session.query(User).order_by(User.name).all()
        locations = session.query(Location).all()
        loc_map = {l.name: l.id for l in locations}
        teams = session.query(Team).all()
        team_map = {t.name: t.id for t in teams}

        col_u1, col_u2 = st.columns([2, 1.2])
        with col_u1:
            st.markdown(f"**Existing Users ({len(all_users)} total):**")
            u_data = []
            for u in all_users:
                u_loc = session.query(Location).filter_by(id=u.location_id).first()
                u_teams = [t.name for t, _ in [
                    (session.query(Team).filter_by(id=ut.team_id).first(), ut.is_primary)
                    for ut in session.query(UserTeam).filter_by(user_id=u.id).all()
                ] if t]
                u_data.append({
                    "ID": u.id,
                    "Emp ID": u.emp_id,
                    "Name": u.name,
                    "Email": u.email,
                    "Role": u.role,
                    "Location": u_loc.name if u_loc else "-",
                    "Teams": ", ".join(u_teams),
                    "Active": u.is_active
                })
            st.dataframe(pd.DataFrame(u_data), use_container_width=True, hide_index=True)

        with col_u2:
            st.markdown("**Add / Provision New User:**")
            with st.form("new_user_form"):
                new_emp_id = st.text_input("Employee ID *", placeholder="e.g. EMP050").strip()
                new_name = st.text_input("Full Name *")
                new_email = st.text_input("Corporate Email *")
                new_role = st.selectbox("Role *", ["Employee", "Team Lead", "Manager", "Director", "Admin"], index=0)
                new_loc = st.selectbox("Location *", list(loc_map.keys()))
                new_pri_team = st.selectbox("Primary Team *", list(team_map.keys()))
                new_pw = st.text_input("Initial Password *", value="welcome123", type="password")
                
                submit_user = st.form_submit_button("Provision User", type="primary")
                if submit_user:
                    if not new_emp_id or not new_name or not new_email:
                        st.error("Please fill in all mandatory fields.")
                    elif session.query(User).filter_by(emp_id=new_emp_id).first():
                        st.error(f"User with Employee ID {new_emp_id} already exists.")
                    else:
                        u_obj = User(
                            emp_id=new_emp_id,
                            name=new_name,
                            email=new_email,
                            role=new_role,
                            password_hash=hash_password(new_pw),
                            location_id=loc_map.get(new_loc),
                            join_date=date.today(),
                            is_active=True,
                            must_change_pw=True
                        )
                        session.add(u_obj)
                        session.flush()
                        session.add(UserTeam(user_id=u_obj.id, team_id=team_map[new_pri_team], is_primary=True))
                        session.commit()
                        st.success(f"User {new_name} provisioned successfully!")
                        st.rerun()

    # ==========================================
    # 2. TEAM MASTER
    # ==========================================
    with tab_teams:
        st.markdown("### Team & Cost Centre Configuration")
        team_list = session.query(Team).all()
        t_rows = []
        for t in team_list:
            lead = session.query(User).filter_by(id=t.lead_user_id).first()
            member_count = session.query(UserTeam).filter_by(team_id=t.id).count()
            t_rows.append({
                "Team ID": t.id,
                "Team Name": t.name,
                "Function": t.function,
                "Cost Centre": t.cost_centre or "-",
                "Team Lead": lead.name if lead else "Unassigned",
                "Members": member_count,
                "Active": t.is_active
            })
        st.dataframe(pd.DataFrame(t_rows), use_container_width=True, hide_index=True)

        with st.form("new_team_form"):
            st.markdown("**Add New Team:**")
            col_tm1, col_tm2, col_tm3 = st.columns(3)
            with col_tm1:
                tm_name = st.text_input("Team Name *")
            with col_tm2:
                tm_func = st.text_input("Operational Function *", value="Record to Report")
            with col_tm3:
                tm_cc = st.text_input("Cost Centre Code", value="CC-105")

            add_tm = st.form_submit_button("Create Team")
            if add_tm:
                if not tm_name:
                    st.error("Team name is required.")
                elif session.query(Team).filter_by(name=tm_name).first():
                    st.error("Team already exists.")
                else:
                    session.add(Team(name=tm_name, function=tm_func, cost_centre=tm_cc, is_active=True))
                    session.commit()
                    st.success(f"Team {tm_name} created!")
                    st.rerun()

    # ==========================================
    # 3. CALCULATION RULES & TARGETS
    # ==========================================
    with tab_rules:
        st.markdown("### Governing Calculation Rules & Target Parameters")
        
        col_r1, col_r2 = st.columns(2)
        with col_r1:
            st.markdown("#### System Settings & Standards")
            with st.form("settings_form"):
                std_hrs = st.number_input("Standard Hours / Day:", min_value=5.0, max_value=12.0, value=float(session.query(Setting).filter_by(key="std_daily_hours").first().value or 7.5), step=0.5)
                tgt_util = st.number_input("Organization Target Utilization %:", min_value=50.0, max_value=100.0, value=float(session.query(Setting).filter_by(key="default_target_util").first().value or 85.0), step=1.0)
                fy_basis = st.selectbox("Fiscal Year Basis:", ["CALENDAR", "FINANCIAL"], index=0 if (session.query(Setting).filter_by(key="fy_basis").first().value or "CALENDAR") == "CALENDAR" else 1)
                month_rule = st.selectbox("Month-Allocation Rule for Straddling Weeks:", ["PRORATE", "ISO_THURSDAY"], index=0 if (session.query(Setting).filter_by(key="month_allocation_rule").first().value or "PRORATE") == "PRORATE" else 1)
                lock_days = st.number_input("Auto-Lock Submissions After (Days post week-end):", min_value=1, max_value=90, value=int(session.query(Setting).filter_by(key="auto_lock_days").first().value or 30))
                
                save_settings = st.form_submit_button("Update Global Settings", type="primary")
                if save_settings:
                    for k, v in [
                        ("std_daily_hours", str(std_hrs)),
                        ("default_target_util", str(tgt_util)),
                        ("fy_basis", fy_basis),
                        ("month_allocation_rule", month_rule),
                        ("auto_lock_days", str(lock_days))
                    ]:
                        s = session.query(Setting).filter_by(key=k).first()
                        if s:
                            s.value = v
                        else:
                            session.add(Setting(key=k, value=v))
                    session.commit()
                    st.success("Global calculation settings updated!")
                    st.rerun()

        with col_r2:
            st.markdown("#### The 9 Categories: BAU vs Value-Add Classification")
            st.caption("Preserve fixed sorting order. Admin can edit BAU/Value-Add tags and display color codes.")
            cats = session.query(Category).order_by(Category.sort_order).all()
            for cat in cats:
                c1, c2, c3 = st.columns([2.5, 1.2, 1.2])
                with c1:
                    st.write(f"**{cat.sort_order}. {cat.name}** (`{cat.code}`)")
                with c2:
                    new_type = st.selectbox(f"Type for {cat.code}", ["BAU", "VALUE_ADD"], index=0 if cat.type == "BAU" else 1, key=f"cat_t_{cat.id}")
                    if new_type != cat.type:
                        cat.type = new_type
                        session.commit()
                with c3:
                    new_color = st.color_picker(f"Color for {cat.code}", cat.color, key=f"cat_c_{cat.id}")
                    if new_color != cat.color:
                        cat.color = new_color
                        session.commit()

        st.markdown("---")
        st.markdown("#### Lock / Unlock Weeks Management")
        c_l1, c_l2 = st.columns([2, 1])
        with c_l1:
            st.write("Lock older submitted weeks to prevent retroactive changes while preserving full audit trail.")
            lock_before_date = st.date_input("Lock all weekly entries submitted before:", value=date.today() - timedelta(days=30))
            if st.button("🔒 Apply Lock to Selected Date Scope"):
                locked_cnt = session.query(WeeklyEntry).filter(WeeklyEntry.week_start <= lock_before_date, WeeklyEntry.locked == False).update({WeeklyEntry.locked: True})
                session.commit()
                st.success(f"Locked {locked_cnt} historical weekly entries.")

    # ==========================================
    # 4. HOLIDAY & LEAVE MASTER
    # ==========================================
    with tab_holidays:
        st.markdown("### Holiday Calendars & Leave Types")
        col_h1, col_h2 = st.columns(2)

        with col_h1:
            st.markdown("#### Leave Types Master")
            leave_types = session.query(LeaveType).all()
            for lt in leave_types:
                clt1, clt2 = st.columns([2, 1])
                with clt1:
                    st.write(f"• **{lt.name}**")
                with clt2:
                    new_exc = st.checkbox("Excluded from Util %", value=lt.excluded_from_utilization, key=f"lt_exc_{lt.id}")
                    if new_exc != lt.excluded_from_utilization:
                        lt.excluded_from_utilization = new_exc
                        session.commit()
                        st.rerun()

        with col_h2:
            st.markdown("#### Public Holidays")
            sel_loc = st.selectbox("Select Location for Holidays:", list(loc_map.keys()), key="hol_loc")
            cur_loc_id = loc_map[sel_loc]
            loc_holidays = session.query(Holiday).filter_by(location_id=cur_loc_id).order_by(Holiday.date).all()
            df_hol = pd.DataFrame([{"Date": h.date.strftime("%Y-%m-%d"), "Holiday Name": h.name} for h in loc_holidays])
            st.dataframe(df_hol, use_container_width=True, hide_index=True)

            with st.form("add_hol_form"):
                h_date = st.date_input("Holiday Date:")
                h_name = st.text_input("Holiday Description:")
                add_h = st.form_submit_button("Add Holiday")
                if add_h and h_name:
                    session.add(Holiday(location_id=cur_loc_id, date=h_date, name=h_name))
                    session.commit()
                    st.success("Holiday added!")
                    st.rerun()

    # ==========================================
    # 5. AUDIT LOG VIEWER
    # ==========================================
    with tab_audit:
        st.markdown("### System Audit Trail (Read-Only)")
        st.caption("Immutable record of all changes to weekly entries, user allocations, and lock states.")
        logs = session.query(AuditLog).order_by(AuditLog.ts.desc()).limit(100).all()
        log_rows = []
        for l in logs:
            u = session.query(User).filter_by(id=l.user_id).first()
            log_rows.append({
                "Timestamp": l.ts.strftime("%Y-%m-%d %H:%M:%S"),
                "User": u.name if u else "System",
                "Action": l.action,
                "Table": l.table_name,
                "Record ID": l.record_id or "-",
                "Old Value": l.old_value or "-",
                "New Value": l.new_value or "-"
            })
        st.dataframe(pd.DataFrame(log_rows), use_container_width=True, hide_index=True)

    # ==========================================
    # 6. BACKUPS & DEMO DATA
    # ==========================================
    with tab_backup:
        st.markdown("### Database Backups & Demo Data Management")
        
        col_b1, col_b2 = st.columns(2)
        with col_b1:
            st.markdown("#### 💾 SQLite Database Backup")
            st.write("Generates a hot point-in-time timestamped copy of `tracker.db` in `data/backups/`.")
            if st.button("📦 Create Database Backup Now", type="primary"):
                backup_dir = os.path.join(BASE_DIR, "data", "backups")
                os.makedirs(backup_dir, exist_ok=True)
                backup_filename = f"tracker_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                backup_path = os.path.join(backup_dir, backup_filename)
                shutil.copy2(DB_PATH, backup_path)
                st.success(f"✅ Backup created successfully: `{backup_filename}`")

            # List backups
            backup_dir = os.path.join(BASE_DIR, "data", "backups")
            if os.path.exists(backup_dir):
                b_files = sorted(os.listdir(backup_dir), reverse=True)
                if b_files:
                    st.caption("Existing Backups:")
                    for bf in b_files[:5]:
                        st.write(f"• `{bf}`")

        with col_b2:
            st.markdown("#### 🧪 Realistic Demo Data Engine")
            st.write("Seed 4 teams, 25 realistic employees, and 52 weeks of close cycles, maternity leaves, and burnout cases for evaluation.")
            
            c_seed, c_wipe = st.columns(2)
            with c_seed:
                if st.button("🌱 Seed Demo Data", use_container_width=True):
                    with st.spinner("Seeding 52 weeks of realistic operational data..."):
                        res = seed_demo_data(session)
                        st.success(res["message"])
                        st.rerun()

            with c_wipe:
                if st.button("🗑️ Wipe Demo Data (Clean State)", use_container_width=True):
                    with st.spinner("Wiping demo records..."):
                        res = clear_demo_data(session)
                        st.success(res["message"])
                        st.rerun()

finally:
    session.close()
