import streamlit as st
from datetime import date, timedelta
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from core.db import SessionLocal, Team, User, Category, LeaveType, Setting
from core.data_service import fetch_and_calculate_telemetry
from core.calendar import get_weeks_for_year, format_week_label, get_month_key, get_month_name
from core.ui_components import apply_custom_css, render_kpi_card, render_sidebar_filters

st.set_page_config(page_title="Management Dashboard — Utilization Tracker", page_icon="📊", layout="wide")
apply_custom_css()

if not st.session_state.get("user"):
    st.warning("⚠️ Please log in from the main page first.")
    if st.button("Go to Login"):
        st.switch_page("app.py")
    st.stop()

session = SessionLocal()

try:
    # Render Global Filters
    filters = render_sidebar_filters(session, default_year="2026")

    # Fetch Telemetry with applied filters
    telemetry = fetch_and_calculate_telemetry(
        session=session,
        year_str=filters["year_str"],
        fy_basis=filters["fy_basis"],
        team_ids=filters["team_ids"],
        user_ids=filters["user_ids"],
        location_ids=filters["location_ids"],
        category_ids=filters["category_ids"],
        cat_type_filter=filters["cat_type_filter"],
        start_week=filters["start_week"],
        end_week=filters["end_week"]
    )

    agg = telemetry["aggregated"]
    weekly_res = telemetry["weekly_results"]
    user_summaries = telemetry["user_summaries"]
    all_cats = telemetry["all_cats"]
    all_teams = telemetry["all_teams"]
    raw_records = telemetry["raw_records"]

    st.markdown("""
    <div class="finance-header">
        <h1>📊 Management Operational Dashboard</h1>
        <p>Operational workload telemetry, heatmaps, team capacity matrices, and compliance quality</p>
    </div>
    """, unsafe_allow_html=True)

    # 1. Executive KPI Cards Row
    k1, k2, k3, k4, k5 = st.columns(5)
    with k1:
        u_val = f"{agg['utilization_pct']:.1f}%" if agg['utilization_pct'] is not None else "N/A"
        var = agg.get('variance_vs_target')
        var_str = f"{var:+.1f} pts vs target" if var is not None else ""
        render_kpi_card("Team Utilization", u_val, var_str)
    with k2:
        render_kpi_card("Total Logged Hours", f"{agg['total_logged_hours']:,.0f} hrs", f"Avail: {agg['total_available_hours']:,.0f} hrs")
    with k3:
        render_kpi_card("Capacity Gap (Net)", f"{agg['capacity_gap']:+,.0f} hrs", "Negative = Overload")
    with k4:
        render_kpi_card("Headcount / FTE", f"{len(user_summaries)} / {agg['avg_fte']:.1f} FTE", "Active pool")
    with k5:
        render_kpi_card("Burnout Flagged", f"{agg['burnout_weeks_count']} wks", f"Under-utilized: {agg['under_util_weeks_count']} wks")

    # 2. Weekly Trend Line & Monthly Bar Chart
    st.markdown("<div class='section-title'>📈 Workload Trajectory & Monthly Distribution</div>", unsafe_allow_html=True)
    c_trend1, c_trend2 = st.columns([1.4, 1.0])

    with c_trend1:
        st.markdown("**Weekly Utilization Trend vs Threshold Bands**")
        # Aggregate weekly results by week_start
        week_grouped = {}
        for r in weekly_res:
            ws = r["week_start"]
            if ws not in week_grouped:
                week_grouped[ws] = {"logged": 0.0, "avail": 0.0, "label": r["week_label"]}
            if not r["is_excluded"]:
                week_grouped[ws]["logged"] += r["logged_hours"]
                week_grouped[ws]["avail"] += r["available_hours"]

        trend_rows = []
        for ws in sorted(week_grouped.keys()):
            d = week_grouped[ws]
            u_p = round((d["logged"] / d["avail"]) * 100.0, 1) if d["avail"] > 0 else None
            trend_rows.append({"Week": d["label"], "Utilization %": u_p, "Logged": d["logged"], "Available": d["avail"]})

        df_weekly_trend = pd.DataFrame(trend_rows)
        if not df_weekly_trend.empty:
            fig_tr = go.Figure()
            # Optimal Target Band (85%)
            fig_tr.add_trace(go.Scatter(x=df_weekly_trend["Week"], y=[85.0]*len(df_weekly_trend), mode="lines", name="Target (85%)", line=dict(color="#10B981", dash="dash", width=2)))
            # Overload Line (100%)
            fig_tr.add_trace(go.Scatter(x=df_weekly_trend["Week"], y=[100.0]*len(df_weekly_trend), mode="lines", name="Overload (100%)", line=dict(color="#DC2626", dash="dot", width=2)))
            # Actual
            fig_tr.add_trace(go.Scatter(x=df_weekly_trend["Week"], y=df_weekly_trend["Utilization %"], mode="lines+markers", name="Actual Team Util %", line=dict(color="#1E3A8A", width=3), marker=dict(size=6, color="#2563EB")))
            fig_tr.update_layout(height=340, margin=dict(l=20, r=20, t=20, b=50), yaxis_title="Utilization %", legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
            st.plotly_chart(fig_tr, use_container_width=True)

    with c_trend2:
        st.markdown("**Monthly Logged vs Available Hours**")
        # Group by month
        month_grouped = {}
        for r in weekly_res:
            m_key = r["week_start"].strftime("%b %Y")
            if m_key not in month_grouped:
                month_grouped[m_key] = {"logged": 0.0, "avail": 0.0}
            if not r["is_excluded"]:
                month_grouped[m_key]["logged"] += r["logged_hours"]
                month_grouped[m_key]["avail"] += r["available_hours"]

        df_month = pd.DataFrame([{"Month": k, "Logged Hours": v["logged"], "Available Hours": v["avail"]} for k, v in month_grouped.items()])
        if not df_month.empty:
            fig_m = px.bar(df_month, x="Month", y=["Logged Hours", "Available Hours"], barmode="group", color_discrete_sequence=["#1E3A8A", "#94A3B8"], height=340)
            fig_m.update_layout(margin=dict(l=20, r=20, t=20, b=40), legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
            st.plotly_chart(fig_m, use_container_width=True)

    # 3. Employee × Week Heatmap
    st.markdown("<div class='section-title'>🔥 Employee × Week Utilization Heatmap</div>", unsafe_allow_html=True)
    st.caption("Visual distribution of employee capacity. Grey cells indicate excluded weeks (Full-week leave, Maternity, Sabbatical). Dark red highlights burnout overload (>100%).")

    heatmap_records = []
    for r in weekly_res:
        u_val = r["utilization_pct"] if not r["is_excluded"] else np.nan
        heatmap_records.append({
            "Employee": f"{r['emp_name']} ({r['emp_id']})",
            "Week": r["week_label"].split(" ")[0],  # e.g. W01
            "Utilization %": u_val,
            "Is Excluded": r["is_excluded"],
            "Exclusion Reason": r["exclusion_reason"],
            "Logged Hours": r["logged_hours"]
        })

    df_hm = pd.DataFrame(heatmap_records)
    if not df_hm.empty:
        pivot_hm = df_hm.pivot_table(index="Employee", columns="Week", values="Utilization %", aggfunc="mean")
        
        fig_hm = px.imshow(
            pivot_hm,
            color_continuous_scale=[
                (0.0, "#FEE2E2"),    # <70% under-utilized
                (0.58, "#FEF3C7"),   # 70-85% below target
                (0.71, "#DCFCE7"),   # 85-100% optimal
                (0.83, "#881337"),   # >100% overload
                (1.0, "#4C0519")     # >130% critical
            ],
            range_color=[50, 130],
            aspect="auto",
            height=max(400, len(pivot_hm) * 22)
        )
        fig_hm.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            xaxis_title="Week",
            yaxis_title="",
            coloraxis_colorbar=dict(title="Util %")
        )
        st.plotly_chart(fig_hm, use_container_width=True)

    # 4. Category × Team Matrix
    st.markdown("<div class='section-title'>🏢 Category × Team Matrix (Hours & Available Share)</div>", unsafe_allow_html=True)
    matrix_records = []
    for r in raw_records:
        if r["logged_hours"] > 0 and r["category"] != "-":
            matrix_records.append({
                "Team": r["team"],
                "Category": r["category"],
                "Hours": r["logged_hours"]
            })

    if matrix_records:
        df_mat = pd.DataFrame(matrix_records)
        pivot_matrix = df_mat.pivot_table(index="Category", columns="Team", values="Hours", aggfunc="sum", fill_value=0.0)
        # Add Row Total
        pivot_matrix["Total Hours"] = pivot_matrix.sum(axis=1)
        st.dataframe(pivot_matrix.style.format("{:,.1f}"), use_container_width=True)

    # 5. Detailed Employee Table
    st.markdown("<div class='section-title'>👥 Individual Employee Performance Table</div>", unsafe_allow_html=True)
    emp_table_rows = []
    for u in user_summaries:
        u_p = f"{u['utilization_pct']:.1f}%" if u['utilization_pct'] is not None else "-"
        emp_table_rows.append({
            "Employee ID": u["emp_id"],
            "Name": u["name"],
            "Team": u["team"],
            "Available (Hrs)": f"{u['available_hours']:.1f}",
            "Logged (Hrs)": f"{u['logged_hours']:.1f}",
            "Utilization %": u_p,
            "Top Category": u["top_category"],
            "Burnout Weeks (>100%)": u["burnout_weeks_count"],
            "Peak Utilization": f"{u['peak_utilization']:.1f}% ({u['peak_week'].split(' ')[0]})",
            "Compliance %": f"{u['compliance_pct']:.0f}%"
        })

    df_emp_table = pd.DataFrame(emp_table_rows)
    search_q = st.text_input("🔍 Search Employee by Name, Team, or ID:", "")
    if search_q:
        df_emp_table = df_emp_table[
            df_emp_table["Name"].str.contains(search_q, case=False) |
            df_emp_table["Team"].str.contains(search_q, case=False) |
            df_emp_table["Employee ID"].str.contains(search_q, case=False)
        ]
    st.dataframe(df_emp_table, use_container_width=True, hide_index=True)

    # 6. Leave & Absence Analysis
    st.markdown("<div class='section-title'>🏖️ Leave & Absence Capacity Impact</div>", unsafe_allow_html=True)
    col_l1, col_l2 = st.columns(2)

    with col_l1:
        st.markdown("**Leave Days Taken by Type**")
        leave_counts = {}
        for r in raw_records:
            lt = r.get("leave_type")
            ld = r.get("leave_days", 0.0)
            if lt and ld > 0:
                leave_counts[lt] = leave_counts.get(lt, 0.0) + (ld / 9.0 if r["category"] != "-" else ld) # normalize raw duplicates

        if leave_counts:
            df_leave = pd.DataFrame([{"Leave Type": k, "Days": round(v, 1)} for k, v in leave_counts.items()])
            fig_l = px.pie(df_leave, names="Leave Type", values="Days", hole=0.4, height=300)
            fig_l.update_layout(margin=dict(l=10, r=10, t=20, b=20))
            st.plotly_chart(fig_l, use_container_width=True)
        else:
            st.info("No leave records found in selected scope.")

    with col_l2:
        st.markdown("**Excluded Weeks Telemetry**")
        exc_weeks = [r for r in weekly_res if r["is_excluded"]]
        st.metric("Total Excluded Weeks", f"{len(exc_weeks)} weeks", f"Capacity dropped from metrics")
        if exc_weeks:
            exc_summary = pd.DataFrame([
                {"Employee": r["emp_name"], "Week": r["week_label"], "Reason": r["exclusion_reason"]}
                for r in exc_weeks[:15]
            ])
            st.dataframe(exc_summary, use_container_width=True, hide_index=True)

    # 7. Data Quality & Audit Exceptions Panel
    st.markdown("<div class='section-title'>⚠️ Data Quality & Anomaly Exceptions Panel</div>", unsafe_allow_html=True)
    with st.expander("Review Data Quality Exceptions & Outliers", expanded=False):
        c_q1, c_q2 = st.columns(2)
        with c_q1:
            st.markdown("**Missing Weekly Submissions:**")
            missing_entries = [r for r in weekly_res if r["status"] == "Missing"]
            if missing_entries:
                df_miss = pd.DataFrame([{"Employee": r["emp_name"], "Week": r["week_label"], "Status": "Not Submitted"} for r in missing_entries[:20]])
                st.dataframe(df_miss, use_container_width=True, hide_index=True)
            else:
                st.success("No missing submissions detected in this filter scope.")

        with c_q2:
            st.markdown("**Unusual Entries (>75 hrs in a single week):**")
            unusual = [r for r in weekly_res if r["logged_hours"] > 75.0]
            if unusual:
                df_un = pd.DataFrame([{"Employee": r["emp_name"], "Week": r["week_label"], "Logged Hours": f"{r['logged_hours']:.1f} hrs"} for r in unusual])
                st.dataframe(df_un, use_container_width=True, hide_index=True)
            else:
                st.success("No extreme outlier hours (>75 hrs/wk) found.")

finally:
    session.close()
