import os
import bcrypt
from datetime import datetime, date

def hash_password(password: str) -> str:
    """Hash a plaintext password using bcrypt."""
    if not isinstance(password, bytes):
        password = password.encode('utf-8')
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password, salt).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plaintext password against a bcrypt hash."""
    if not plain_password or not hashed_password:
        return False
    try:
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    except Exception:
        return False

# Role constants
ROLE_EMPLOYEE = "Employee"
ROLE_TEAM_LEAD = "Team Lead"
ROLE_MANAGER = "Manager"
ROLE_DIRECTOR = "Director"
ROLE_ADMIN = "Admin"

ROLE_HIERARCHY = {
    ROLE_EMPLOYEE: 1,
    ROLE_TEAM_LEAD: 2,
    ROLE_MANAGER: 3,
    ROLE_DIRECTOR: 4,
    ROLE_ADMIN: 5,
}

def has_min_role(user_role: str, required_role: str) -> bool:
    """Check if user_role meets or exceeds required_role."""
    return ROLE_HIERARCHY.get(user_role, 0) >= ROLE_HIERARCHY.get(required_role, 999)
