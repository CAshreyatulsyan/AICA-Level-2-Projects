from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import List, Dict, Optional, Tuple, Set

STD_DAILY_HOURS = 7.5

@dataclass
class LeaveRecord:
    leave_type_name: str
    days: float
    is_excluded_type: bool = False

@dataclass
class HourRecord:
    team_id: int
    category_id: int
    hours: float
    category_code: str = ""
    category_name: str = ""
    category_type: str = "BAU"  # BAU or VALUE_ADD

@dataclass
class WeekCalculationResult:
    week_start: date
    working_days: int
    total_leave_days: float
    excluded_leave_days: float
    is_excluded: bool
    exclusion_reason: str
    available_hours: float
    logged_hours: float
    utilization_pct: Optional[float]
    fte: float
    capacity_gap: float  # available - logged
    is_burnout: bool
    burnout_tier: Optional[str]  # None, 'Watch', 'High', 'Critical'
    hours_by_team: Dict[int, float] = field(default_factory=dict)
    available_by_team: Dict[int, float] = field(default_factory=dict)
    hours_by_category: Dict[int, float] = field(default_factory=dict)
    hours_in_excluded_week: float = 0.0

def get_burnout_tier(utilization_pct: Optional[float], burnout_threshold: float = 100.0) -> Optional[str]:
    """Return burnout severity tier if utilization exceeds threshold."""
    if utilization_pct is None or utilization_pct <= burnout_threshold:
        return None
    if utilization_pct <= 110.0:
        return "Watch"
    elif utilization_pct <= 120.0:
        return "High"
    else:
        return "Critical"

def get_utilization_status(utilization_pct: Optional[float], is_excluded: bool = False, exclusion_reason: str = "") -> str:
    """Return human readable status string and threshold category."""
    if is_excluded:
        return f"Excluded ({exclusion_reason})" if exclusion_reason else "Excluded"
    if utilization_pct is None:
        return "No Target / N/A"
    if utilization_pct < 70.0:
        return "Under-utilized (<70%)"
    elif utilization_pct < 85.0:
        return "Below Target (70-85%)"
    elif utilization_pct <= 100.0:
        return "Optimal (85-100%)"
    else:
        return f"Overloaded (>100% - {get_burnout_tier(utilization_pct)})"

def calculate_week_utilization(
    week_start: date,
    working_days: int,
    leaves: List[LeaveRecord],
    hours_records: List[HourRecord],
    primary_team_id: Optional[int] = None,
    std_daily_hours: float = STD_DAILY_HOURS,
    join_date: Optional[date] = None,
    exit_date: Optional[date] = None,
    force_full_week_leave: bool = False
) -> WeekCalculationResult:
    """
    Pure function to calculate weekly utilization and capacity metrics for an employee.
    """
    week_end = week_start + timedelta(days=6)

    # 1. Tenure Exclusion Check
    if join_date and join_date > week_end:
        return WeekCalculationResult(
            week_start=week_start,
            working_days=working_days,
            total_leave_days=0.0,
            excluded_leave_days=0.0,
            is_excluded=True,
            exclusion_reason="Prior to Joining",
            available_hours=0.0,
            logged_hours=0.0,
            utilization_pct=None,
            fte=0.0,
            capacity_gap=0.0,
            is_burnout=False,
            burnout_tier=None,
            hours_in_excluded_week=0.0
        )

    if exit_date and exit_date < week_start:
        return WeekCalculationResult(
            week_start=week_start,
            working_days=working_days,
            total_leave_days=0.0,
            excluded_leave_days=0.0,
            is_excluded=True,
            exclusion_reason="After Exit",
            available_hours=0.0,
            logged_hours=0.0,
            utilization_pct=None,
            fte=0.0,
            capacity_gap=0.0,
            is_burnout=False,
            burnout_tier=None,
            hours_in_excluded_week=0.0
        )

    # 2. Leave and Exclusions
    total_leave_days = sum(l.days for l in leaves)
    excluded_leave_days = sum(l.days for l in leaves if l.is_excluded_type)
    excluded_leave_reasons = [l.leave_type_name for l in leaves if l.is_excluded_type and l.days > 0]

    # Check full week exclusion
    is_excluded = False
    exclusion_reason = ""

    if force_full_week_leave:
        is_excluded = True
        exclusion_reason = "Full-week Leave"
    elif any(l.is_excluded_type and l.days >= working_days for l in leaves) and working_days > 0:
        is_excluded = True
        exclusion_reason = excluded_leave_reasons[0] if excluded_leave_reasons else "Excluded Leave"
    elif working_days == 0:
        # Holiday week with 0 working days
        is_excluded = True
        exclusion_reason = "Public Holiday Week"
    elif any(l.is_excluded_type and ("Maternity" in l.leave_type_name or "Sabbatical" in l.leave_type_name or "Medical" in l.leave_type_name) and l.days >= 3.0 for l in leaves):
        # Long-term leave spanning major week
        is_excluded = True
        exclusion_reason = excluded_leave_reasons[0]
    elif total_leave_days >= working_days and working_days > 0:
        # Employee on leave entire working week
        is_excluded = True
        exclusion_reason = excluded_leave_reasons[0] if excluded_leave_reasons else "On Leave Entire Week"

    # Total logged hours
    total_logged_hours = sum(h.hours for h in hours_records)

    # Team & Category aggregations
    hours_by_team: Dict[int, float] = {}
    hours_by_cat: Dict[int, float] = {}
    for h in hours_records:
        hours_by_team[h.team_id] = hours_by_team.get(h.team_id, 0.0) + h.hours
        hours_by_cat[h.category_id] = hours_by_cat.get(h.category_id, 0.0) + h.hours

    if is_excluded:
        # In an excluded week, available hours = 0 and both numerator and denominator dropped
        return WeekCalculationResult(
            week_start=week_start,
            working_days=working_days,
            total_leave_days=total_leave_days,
            excluded_leave_days=excluded_leave_days,
            is_excluded=True,
            exclusion_reason=exclusion_reason,
            available_hours=0.0,
            logged_hours=0.0,
            utilization_pct=None,
            fte=round(total_logged_hours / (std_daily_hours * working_days), 2) if working_days > 0 else 0.0,
            capacity_gap=0.0,
            is_burnout=False,
            burnout_tier=None,
            hours_by_team=hours_by_team,
            available_by_team={},
            hours_by_category=hours_by_cat,
            hours_in_excluded_week=total_logged_hours
        )

    # Available hours calculation
    # Regular leave reduces available hours: (working_days - total_leave_days) * std_daily_hours
    effective_working_days = max(0.0, float(working_days) - total_leave_days)
    available_hours = round(effective_working_days * std_daily_hours, 2)

    # Utilization %
    if available_hours > 0:
        utilization_pct = round((total_logged_hours / available_hours) * 100.0, 1)
    else:
        # Edge case: 0 available hours but not marked excluded
        utilization_pct = 100.0 if total_logged_hours == 0 else round((total_logged_hours / 0.1) * 100.0, 1)

    # Burnout
    is_burnout = bool(utilization_pct is not None and utilization_pct > 100.0)
    burnout_tier = get_burnout_tier(utilization_pct) if is_burnout else None

    # Capacity Gap: Available - Logged (negative = overload)
    capacity_gap = round(available_hours - total_logged_hours, 2)

    # FTE equivalent: logged_hours / (std_daily_hours * working_days)
    fte = round(total_logged_hours / (std_daily_hours * working_days), 2) if working_days > 0 else 0.0

    # Team attribution of available hours:
    # Proportional to logged hours across teams; if 0 hours, 100% to primary_team_id
    available_by_team: Dict[int, float] = {}
    if total_logged_hours > 0:
        for t_id, t_hours in hours_by_team.items():
            available_by_team[t_id] = round(available_hours * (t_hours / total_logged_hours), 2)
    elif primary_team_id is not None:
        available_by_team[primary_team_id] = available_hours
    elif hours_by_team:
        first_t = list(hours_by_team.keys())[0]
        available_by_team[first_t] = available_hours

    return WeekCalculationResult(
        week_start=week_start,
        working_days=working_days,
        total_leave_days=total_leave_days,
        excluded_leave_days=excluded_leave_days,
        is_excluded=False,
        exclusion_reason="",
        available_hours=available_hours,
        logged_hours=round(total_logged_hours, 2),
        utilization_pct=utilization_pct,
        fte=fte,
        capacity_gap=capacity_gap,
        is_burnout=is_burnout,
        burnout_tier=burnout_tier,
        hours_by_team=hours_by_team,
        available_by_team=available_by_team,
        hours_by_category=hours_by_cat,
        hours_in_excluded_week=0.0
    )

def aggregate_utilization(
    results: List[WeekCalculationResult],
    target_util_pct: float = 85.0
) -> Dict[str, any]:
    """
    Weighted hours aggregation across multiple week calculation results.
    Dropped excluded weeks from numerator and denominator.
    """
    included_weeks = [r for r in results if not r.is_excluded]
    excluded_weeks = [r for r in results if r.is_excluded]

    total_logged = sum(r.logged_hours for r in included_weeks)
    total_available = sum(r.available_hours for r in included_weeks)
    excluded_logged = sum(r.hours_in_excluded_week for r in excluded_weeks)

    if total_available > 0:
        overall_utilization_pct = round((total_logged / total_available) * 100.0, 1)
    else:
        overall_utilization_pct = None

    burnout_weeks_count = sum(1 for r in included_weeks if r.is_burnout)
    under_util_weeks_count = sum(1 for r in included_weeks if r.utilization_pct is not None and r.utilization_pct < 70.0)

    # Consecutive burnout streaks
    max_burnout_streak = 0
    current_streak = 0
    for r in sorted(included_weeks, key=lambda x: x.week_start):
        if r.is_burnout:
            current_streak += 1
            if current_streak > max_burnout_streak:
                max_burnout_streak = current_streak
        else:
            current_streak = 0

    # Aggregate by team
    team_logged: Dict[int, float] = {}
    team_available: Dict[int, float] = {}
    for r in included_weeks:
        for t_id, hrs in r.hours_by_team.items():
            team_logged[t_id] = team_logged.get(t_id, 0.0) + hrs
        for t_id, hrs in r.available_by_team.items():
            team_available[t_id] = team_available.get(t_id, 0.0) + hrs

    team_utilization: Dict[int, Dict[str, float]] = {}
    for t_id in set(list(team_logged.keys()) + list(team_available.keys())):
        l_hrs = team_logged.get(t_id, 0.0)
        a_hrs = team_available.get(t_id, 0.0)
        u_pct = round((l_hrs / a_hrs) * 100.0, 1) if a_hrs > 0 else None
        team_utilization[t_id] = {
            "logged": round(l_hrs, 2),
            "available": round(a_hrs, 2),
            "utilization_pct": u_pct
        }

    # Aggregate by category
    cat_hours: Dict[int, float] = {}
    for r in included_weeks:
        for c_id, hrs in r.hours_by_category.items():
            cat_hours[c_id] = cat_hours.get(c_id, 0.0) + hrs

    cat_analysis: Dict[int, Dict[str, float]] = {}
    for c_id, hrs in cat_hours.items():
        # Category util % = category hours / sum(available)
        cat_util = round((hrs / total_available) * 100.0, 1) if total_available > 0 else 0.0
        # Category mix % = category hours / total logged hours
        cat_mix = round((hrs / total_logged) * 100.0, 1) if total_logged > 0 else 0.0
        cat_analysis[c_id] = {
            "hours": round(hrs, 2),
            "utilization_pct": cat_util,
            "mix_pct": cat_mix
        }

    total_capacity_gap = round(total_available - total_logged, 2)
    avg_fte = round(sum(r.fte for r in included_weeks) / len(included_weeks), 2) if included_weeks else 0.0

    return {
        "total_weeks": len(results),
        "included_weeks_count": len(included_weeks),
        "excluded_weeks_count": len(excluded_weeks),
        "total_logged_hours": round(total_logged, 2),
        "total_available_hours": round(total_available, 2),
        "excluded_logged_hours": round(excluded_logged, 2),
        "utilization_pct": overall_utilization_pct,
        "target_util_pct": target_util_pct,
        "variance_vs_target": round(overall_utilization_pct - target_util_pct, 1) if overall_utilization_pct is not None else None,
        "burnout_weeks_count": burnout_weeks_count,
        "under_util_weeks_count": under_util_weeks_count,
        "max_burnout_streak": max_burnout_streak,
        "capacity_gap": total_capacity_gap,
        "avg_fte": avg_fte,
        "team_metrics": team_utilization,
        "category_metrics": cat_analysis
    }
