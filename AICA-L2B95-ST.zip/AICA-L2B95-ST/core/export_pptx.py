import io
from datetime import datetime
from typing import Dict, Any, List, Optional
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_director_presentation(
    summary_data: Dict[str, Any],
    filters_info: Dict[str, str],
    insights_list: List[str],
    team_data: List[Dict[str, Any]],
    cat_data: List[Dict[str, Any]],
    burnout_data: List[Dict[str, Any]],
    chart_images: Optional[Dict[str, bytes]] = None
) -> io.BytesIO:
    """
    Generate an executive 8-slide presentation deck using python-pptx.
    """
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    NAVY = RGBColor(30, 58, 138)
    WHITE = RGBColor(255, 255, 255)
    DARK_GRAY = RGBColor(30, 41, 59)
    MUTED_GRAY = RGBColor(100, 116, 139)
    LIGHT_BG = RGBColor(248, 250, 252)
    ACCENT_BLUE = RGBColor(37, 99, 235)
    ACCENT_GREEN = RGBColor(22, 101, 52)
    ACCENT_RED = RGBColor(153, 27, 27)

    def add_slide_header(slide, title_text: str, subtitle_text: str = ""):
        # Header banner
        header_shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(1.1)
        )
        header_shape.fill.solid()
        header_shape.fill.fore_color.rgb = NAVY
        header_shape.line.fill.background()

        tf = header_shape.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.8)
        tf.margin_top = Inches(0.15)
        p = tf.paragraphs[0]
        p.text = title_text
        p.font.size = Pt(22)
        p.font.bold = True
        p.font.color.rgb = WHITE

        if subtitle_text:
            p2 = tf.add_paragraph()
            p2.text = subtitle_text
            p2.font.size = Pt(11)
            p2.font.color.rgb = RGBColor(203, 213, 225)

        # Footer filter breadcrumb
        footer_box = slide.shapes.add_textbox(Inches(0.8), Inches(7.05), Inches(11.7), Inches(0.4))
        ftf = footer_box.text_frame
        fp = ftf.paragraphs[0]
        filter_str = " | ".join(f"{k}: {v}" for k, v in filters_info.items())
        fp.text = f"Scope: {filter_str}  •  Finance Shared Services Confidential"
        fp.font.size = Pt(9)
        fp.font.color.rgb = MUTED_GRAY

    blank_layout = prs.slide_layouts[6]

    # ==========================================
    # SLIDE 1: TITLE SLIDE
    # ==========================================
    s1 = prs.slides.add_slide(blank_layout)
    bg = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    bg.fill.solid()
    bg.fill.fore_color.rgb = NAVY
    bg.line.fill.background()

    tb = s1.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(11.3), Inches(3.2))
    tf = tb.text_frame
    p = tf.paragraphs[0]
    p.text = "Finance Team Utilization & Capacity"
    p.font.size = Pt(40)
    p.font.bold = True
    p.font.color.rgb = WHITE

    p2 = tf.add_paragraph()
    p2.text = "Director & Management Review Deck  |  Record-to-Report Operations"
    p2.font.size = Pt(20)
    p2.font.color.rgb = RGBColor(147, 197, 253)

    p3 = tf.add_paragraph()
    p3.text = f"\nGenerated: {datetime.now().strftime('%d %B %Y')}  |  Scope: {filters_info.get('Period', 'All')} ({filters_info.get('Year', '2026')})"
    p3.font.size = Pt(13)
    p3.font.color.rgb = RGBColor(226, 232, 240)

    # ==========================================
    # SLIDE 2: EXECUTIVE SUMMARY
    # ==========================================
    s2 = prs.slides.add_slide(blank_layout)
    add_slide_header(s2, "Executive KPI Summary", "Key capacity, workload, and utilization performance indicators")

    # Add 4 KPI cards
    kpis = [
        ("Utilization Rate", f"{summary_data.get('utilization_pct', 0.0):.1f}%", f"Target: {summary_data.get('target_util_pct', 85):.0f}%"),
        ("Total Logged Hours", f"{summary_data.get('total_logged_hours', 0.0):,.0f} hrs", f"Avail: {summary_data.get('total_available_hours', 0.0):,.0f} hrs"),
        ("Capacity Deficit / Gap", f"{summary_data.get('capacity_gap', 0.0):+,.0f} hrs", "Negative = Overload"),
        ("Overloaded Headcount", f"{len(burnout_data)} Employees", f"{summary_data.get('burnout_weeks_count', 0)} Breached Weeks"),
    ]

    for idx, (title, val, sub) in enumerate(kpis):
        left = Inches(0.8 + idx * 2.95)
        top = Inches(1.5)
        card = s2.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, Inches(2.8), Inches(1.8))
        card.fill.solid()
        card.fill.fore_color.rgb = RGBColor(241, 245, 249)
        card.line.color.rgb = RGBColor(203, 213, 225)

        ctf = card.text_frame
        ctf.margin_top = Inches(0.2)
        cp1 = ctf.paragraphs[0]
        cp1.text = title
        cp1.font.size = Pt(11)
        cp1.font.bold = True
        cp1.font.color.rgb = MUTED_GRAY

        cp2 = ctf.add_paragraph()
        cp2.text = val
        cp2.font.size = Pt(26)
        cp2.font.bold = True
        cp2.font.color.rgb = NAVY

        cp3 = ctf.add_paragraph()
        cp3.text = sub
        cp3.font.size = Pt(10)
        cp3.font.color.rgb = DARK_GRAY

    # Narrative callout on Slide 2
    sum_box = s2.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(3.6), Inches(11.7), Inches(3.2))
    sum_box.fill.solid()
    sum_box.fill.fore_color.rgb = WHITE
    sum_box.line.color.rgb = RGBColor(226, 232, 240)
    stf = sum_box.text_frame
    stf.margin_left = Inches(0.4)
    stf.margin_top = Inches(0.3)
    sp0 = stf.paragraphs[0]
    sp0.text = "Operational Overview & Capacity Health"
    sp0.font.size = Pt(15)
    sp0.font.bold = True
    sp0.font.color.rgb = NAVY

    for ins in insights_list[:4]:
        sp = stf.add_paragraph()
        sp.text = f"•  {ins.replace('**', '')}"
        sp.font.size = Pt(12)
        sp.font.color.rgb = DARK_GRAY

    # ==========================================
    # SLIDE 3: TEAM COMPARISON
    # ==========================================
    s3 = prs.slides.add_slide(blank_layout)
    add_slide_header(s3, "Team Performance & Variance vs Target", "Comparative utilization and capacity distribution across sub-teams")

    # Team table
    rows = len(team_data) + 1
    table_shape = s3.shapes.add_table(rows, 5, Inches(0.8), Inches(1.5), Inches(11.7), Inches(0.4 * rows))
    tbl = table_shape.table
    tbl.columns[0].width = Inches(3.5)
    tbl.columns[1].width = Inches(2.0)
    tbl.columns[2].width = Inches(2.0)
    tbl.columns[3].width = Inches(2.0)
    tbl.columns[4].width = Inches(2.2)

    headers = ["Team Name", "Logged Hours", "Available Hours", "Utilization %", "Status"]
    for ci, h in enumerate(headers):
        cell = tbl.cell(0, ci)
        cell.fill.solid()
        cell.fill.fore_color.rgb = NAVY
        p = cell.text_frame.paragraphs[0]
        p.text = h
        p.font.bold = True
        p.font.size = Pt(11)
        p.font.color.rgb = WHITE

    for ri, td in enumerate(team_data, start=1):
        tbl.cell(ri, 0).text_frame.paragraphs[0].text = str(td.get("name", ""))
        tbl.cell(ri, 1).text_frame.paragraphs[0].text = f"{td.get('logged', 0):,.1f}"
        tbl.cell(ri, 2).text_frame.paragraphs[0].text = f"{td.get('available', 0):,.1f}"
        u_pct = td.get('utilization_pct')
        tbl.cell(ri, 3).text_frame.paragraphs[0].text = f"{u_pct:.1f}%" if u_pct is not None else "-"
        status = "Optimal" if u_pct and 85 <= u_pct <= 100 else ("Overloaded" if u_pct and u_pct > 100 else "Below Target")
        tbl.cell(ri, 4).text_frame.paragraphs[0].text = status

    # ==========================================
    # SLIDE 4: CATEGORY MIX & TRANSFORMATION
    # ==========================================
    s4 = prs.slides.add_slide(blank_layout)
    add_slide_header(s4, "Activity Category Breakdown & Portfolio Mix", "BAU operational load vs Value-Add / Continuous Improvement investments")

    rows = min(len(cat_data) + 1, 11)
    table_shape = s4.shapes.add_table(rows, 5, Inches(0.8), Inches(1.5), Inches(11.7), Inches(0.4 * rows))
    tbl = table_shape.table
    tbl.columns[0].width = Inches(4.5)
    tbl.columns[1].width = Inches(1.8)
    tbl.columns[2].width = Inches(1.8)
    tbl.columns[3].width = Inches(1.8)
    tbl.columns[4].width = Inches(1.8)

    headers = ["Category", "Type", "Logged Hours", "Mix %", "Util %"]
    for ci, h in enumerate(headers):
        cell = tbl.cell(0, ci)
        cell.fill.solid()
        cell.fill.fore_color.rgb = NAVY
        p = cell.text_frame.paragraphs[0]
        p.text = h
        p.font.bold = True
        p.font.size = Pt(11)
        p.font.color.rgb = WHITE

    for ri, cd in enumerate(cat_data[:10], start=1):
        tbl.cell(ri, 0).text_frame.paragraphs[0].text = str(cd.get("name", ""))
        tbl.cell(ri, 1).text_frame.paragraphs[0].text = str(cd.get("type", "BAU"))
        tbl.cell(ri, 2).text_frame.paragraphs[0].text = f"{cd.get('hours', 0):,.1f}"
        tbl.cell(ri, 3).text_frame.paragraphs[0].text = f"{cd.get('mix_pct', 0):.1f}%"
        tbl.cell(ri, 4).text_frame.paragraphs[0].text = f"{cd.get('util_pct', 0):.1f}%"

    # ==========================================
    # SLIDE 5: WORKLOAD TRENDS & CLOSE CYCLE
    # ==========================================
    s5 = prs.slides.add_slide(blank_layout)
    add_slide_header(s5, "Workload Trajectory & Close Cycle Dynamics", "Month-end close compression vs normal operating baseline")

    tb = s5.shapes.add_textbox(Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.0))
    tf = tb.text_frame
    p = tf.paragraphs[0]
    p.text = "Key Close Cycle Observations:"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = NAVY

    points = [
        "Record-to-Report Close Effort peaks sharply between WD-2 and WD+4 across all months.",
        "Category 1 (Period-End Close) and Category 2 (Reporting) absorb >60% of total operational hours during close weeks.",
        "Overtime spikes concentrate in Quarter-End and Year-End cycles (March, June, September, December).",
        "Non-close weeks (WD+8 to WD-5) display capacity slack, which should be protected for Automation (Category 6) and reconciliations catch-up."
    ]
    for pt in points:
        p_sub = tf.add_paragraph()
        p_sub.text = f"•  {pt}"
        p_sub.font.size = Pt(13)
        p_sub.font.color.rgb = DARK_GRAY

    # ==========================================
    # SLIDE 6: BURNOUT & ATTRITION RISK
    # ==========================================
    s6 = prs.slides.add_slide(blank_layout)
    add_slide_header(s6, "Burnout & Attrition Risk Monitor", "Employees exceeding 100% capacity threshold and consecutive overload streaks")

    b_box = s6.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.2))
    b_box.fill.solid()
    b_box.fill.fore_color.rgb = WHITE
    b_box.line.color.rgb = RGBColor(226, 232, 240)
    btf = b_box.text_frame
    btf.margin_left = Inches(0.4)
    btf.margin_top = Inches(0.3)

    bp0 = btf.paragraphs[0]
    bp0.text = "Burnout Risk Policy & Summary"
    bp0.font.size = Pt(15)
    bp0.font.bold = True
    bp0.font.color.rgb = ACCENT_RED

    bp1 = btf.add_paragraph()
    bp1.text = f"Total Overloaded Individuals: {len(burnout_data)} employees logged >100% utilization in one or more included weeks."
    bp1.font.size = Pt(12)
    bp1.font.bold = True
    bp1.font.color.rgb = DARK_GRAY

    for b in burnout_data[:5]:
        bp = btf.add_paragraph()
        bp.text = f"•  {b.get('name')} ({b.get('team')}): {b.get('flagged_weeks')} flagged weeks, Max Streak: {b.get('consecutive_streak')} wks, Peak: {b.get('peak_utilization'):.1f}% ({b.get('severity')})"
        bp.font.size = Pt(11)
        bp.font.color.rgb = DARK_GRAY

    # ==========================================
    # SLIDE 7: INSIGHTS & RECOMMENDATIONS
    # ==========================================
    s7 = prs.slides.add_slide(blank_layout)
    add_slide_header(s7, "Automated Operational Insights & Recommendations", "Deterministic, rule-based findings generated from tracking telemetry")

    ins_box = s7.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.2))
    ins_box.fill.solid()
    ins_box.fill.fore_color.rgb = WHITE
    ins_box.line.color.rgb = RGBColor(226, 232, 240)
    itf = ins_box.text_frame
    itf.margin_left = Inches(0.4)
    itf.margin_top = Inches(0.3)

    ip0 = itf.paragraphs[0]
    ip0.text = "Key Management Insights"
    ip0.font.size = Pt(15)
    ip0.font.bold = True
    ip0.font.color.rgb = NAVY

    for ins in insights_list:
        ip = itf.add_paragraph()
        ip.text = f"•  {ins.replace('**', '')}"
        ip.font.size = Pt(12)
        ip.font.color.rgb = DARK_GRAY

    # ==========================================
    # SLIDE 8: APPENDIX & METHODOLOGY
    # ==========================================
    s8 = prs.slides.add_slide(blank_layout)
    add_slide_header(s8, "Appendix: Methodology & Governance Rules", "Mathematical definitions and system validation principles")

    app_box = s8.shapes.add_textbox(Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.2))
    atf = app_box.text_frame
    ap0 = atf.paragraphs[0]
    ap0.text = "Standard Operating Principles"
    ap0.font.size = Pt(15)
    ap0.font.bold = True
    ap0.font.color.rgb = NAVY

    rules = [
        "Standard Daily Hours: 7.5 hours/day standard working day baseline.",
        "Available Hours (Week) = (Working Days [Mon-Fri less Location Holidays] - Total Leave Days) × 7.5.",
        "Excluded Weeks: Full-week leave, maternity/paternity, sabbatical, and long-term medical leave drop numerator and denominator completely.",
        "Hours-Weighted Aggregation: Monthly and yearly metrics use Σ Logged Hours ÷ Σ Available Hours (Never average of percentages).",
        "Threshold Tiers: <70% Under-utilized; 70-85% Below Target; 85-100% Optimal; >100% Burnout Overload (Watch 100-110%, High 110-120%, Critical >120%).",
        "Multi-Team Allocation: Available hours are split across teams proportionally to weekly logged hours."
    ]
    for r in rules:
        ap = atf.add_paragraph()
        ap.text = f"•  {r}"
        ap.font.size = Pt(12)
        ap.font.color.rgb = DARK_GRAY

    output = io.BytesIO()
    prs.save(output)
    output.seek(0)
    return output
