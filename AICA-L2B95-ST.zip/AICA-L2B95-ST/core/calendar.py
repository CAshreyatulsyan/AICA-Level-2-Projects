from datetime import date, datetime, timedelta
from typing import List, Tuple, Dict, Optional, Set

def get_monday(d: date) -> date:
    """Return the Monday of the week containing date d."""
    return d - timedelta(days=d.weekday())

def get_sunday(d: date) -> date:
    """Return the Sunday of the week containing date d."""
    return get_monday(d) + timedelta(days=6)

def get_week_days(week_start: date) -> List[date]:
    """Return all 7 dates in the week starting from Monday week_start."""
    return [week_start + timedelta(days=i) for i in range(7)]

def get_working_days_in_week(week_start: date, holiday_dates: Optional[Set[date]] = None) -> int:
    """
    Return count of working days (Mon-Fri) excluding public holidays falling on Mon-Fri.
    """
    if holiday_dates is None:
        holiday_dates = set()
    days = get_week_days(week_start)[:5]  # Mon-Fri
    working = sum(1 for d in days if d not in holiday_dates)
    return working

def get_working_days_list(week_start: date, holiday_dates: Optional[Set[date]] = None) -> List[date]:
    """Return the list of working dates (Mon-Fri not on holidays)."""
    if holiday_dates is None:
        holiday_dates = set()
    return [d for d in get_week_days(week_start)[:5] if d not in holiday_dates]

def format_week_label(week_start: date) -> str:
    """e.g., 'W01 (05 Jan - 11 Jan 2026)'"""
    iso_year, iso_week, _ = week_start.isocalendar()
    week_end = week_start + timedelta(days=6)
    return f"W{iso_week:02d} ({week_start.strftime('%d %b')} - {week_end.strftime('%d %b %Y')})"

def get_fiscal_year(d: date, fy_basis: str = "CALENDAR") -> str:
    """
    Return fiscal year string.
    CALENDAR: '2026' for any date in 2026.
    FINANCIAL: 'FY2025-26' for Apr 2025 - Mar 2026.
    """
    if fy_basis.upper() == "FINANCIAL":
        if d.month >= 4:
            return f"FY{d.year}-{str(d.year + 1)[-2:]}"
        else:
            return f"FY{d.year - 1}-{str(d.year)[-2:]}"
    return str(d.year)

def get_month_key(d: date) -> str:
    """e.g. '2026-03'"""
    return d.strftime("%Y-%m")

def get_month_name(d: date) -> str:
    """e.g. 'Mar 2026'"""
    return d.strftime("%b %Y")

def get_weeks_in_range(start_date: date, end_date: date) -> List[date]:
    """Return list of Monday dates for all weeks intersecting start_date to end_date."""
    cur = get_monday(start_date)
    weeks = []
    end_mon = get_monday(end_date)
    while cur <= end_mon:
        weeks.append(cur)
        cur += timedelta(days=7)
    return weeks

def get_weeks_for_year(year_val: str, fy_basis: str = "CALENDAR") -> List[date]:
    """
    Return list of week_start dates for the specified year string.
    If CALENDAR: year_val is '2026' -> Jan 1 to Dec 31.
    If FINANCIAL: year_val is 'FY2025-26' -> Apr 1 2025 to Mar 31 2026.
    """
    if fy_basis.upper() == "FINANCIAL":
        # Parse 'FY2025-26' or '2025-26'
        start_year = int(year_val.replace("FY", "").split("-")[0])
        start_date = date(start_year, 4, 1)
        end_date = date(start_year + 1, 3, 31)
    else:
        y = int(year_val)
        start_date = date(y, 1, 1)
        end_date = date(y, 12, 31)
    return get_weeks_in_range(start_date, end_date)

def allocate_week_to_months(
    week_start: date,
    logged_hours: float,
    available_hours: float,
    rule: str = "PRORATE",
    holiday_dates: Optional[Set[date]] = None
) -> Dict[str, Dict[str, float]]:
    """
    Splits logged and available hours into months.
    Returns: { 'YYYY-MM': {'logged': float, 'available': float, 'working_days': int} }
    """
    if holiday_dates is None:
        holiday_dates = set()

    thursday = week_start + timedelta(days=3)
    if rule == "ISO_THURSDAY":
        m_key = get_month_key(thursday)
        w_days = get_working_days_in_week(week_start, holiday_dates)
        return {
            m_key: {
                "logged": logged_hours,
                "available": available_hours,
                "working_days": w_days
            }
        }

    # Default PRORATE by working days
    mon_fri = [week_start + timedelta(days=i) for i in range(5)]
    working_days = [d for d in mon_fri if d not in holiday_dates]
    total_w_days = len(working_days)

    if total_w_days == 0:
        # If no working days in week, assign to Thursday's month
        m_key = get_month_key(thursday)
        return {
            m_key: {
                "logged": logged_hours,
                "available": available_hours,
                "working_days": 0
            }
        }

    # Count working days per month
    month_counts: Dict[str, int] = {}
    for d in working_days:
        m = get_month_key(d)
        month_counts[m] = month_counts.get(m, 0) + 1

    res = {}
    for m, count in month_counts.items():
        ratio = count / total_w_days
        res[m] = {
            "logged": round(logged_hours * ratio, 2),
            "available": round(available_hours * ratio, 2),
            "working_days": count
        }
    return res

def get_close_cycle_day(d: date, holiday_dates: Optional[Set[date]] = None) -> Optional[str]:
    """
    For a given date, compute its Close-Cycle working-day tag relative to month end / month start:
    - Pre-close: WD-5, WD-4, WD-3, WD-2, WD-1 (last 5 working days of previous/current month)
    - Post-close: WD+1, WD+2, ... WD+8 (first 8 working days of new month)
    """
    if holiday_dates is None:
        holiday_dates = set()

    if d.weekday() >= 5 or d in holiday_dates:
        return None  # weekend or holiday

    # Check if d is in the first 8 working days of its month
    # Find all working days in d.year, d.month
    first_of_month = date(d.year, d.month, 1)
    # Next month first day
    if d.month == 12:
        next_month = date(d.year + 1, 1, 1)
    else:
        next_month = date(d.year, d.month + 1, 1)

    cur = first_of_month
    month_working_days = []
    while cur < next_month:
        if cur.weekday() < 5 and cur not in holiday_dates:
            month_working_days.append(cur)
        cur += timedelta(days=1)

    if d in month_working_days:
        idx = month_working_days.index(d) + 1  # 1-indexed
        if idx <= 8:
            return f"WD+{idx}"
        # Check from end: e.g. last 5 working days
        total_w = len(month_working_days)
        days_from_end = total_w - idx + 1
        if days_from_end <= 5:
            return f"WD-{days_from_end}"

    return None
