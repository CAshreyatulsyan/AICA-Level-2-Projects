import streamlit as st
from datetime import date, timedelta
from typing import Dict, Any, List, Optional, Tuple
from core.db import SessionLocal, Team, User, Location, Category, Setting
from core.calendar import get_weeks_for_year, format_week_label

def apply_custom_css():
    """Inject clean, modern corporate CSS for Finance Shared Services."""
    st.markdown("""
    <style>
    /* Main container and font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    
    /* Top header decoration */
    .finance-header {
        background: linear-gradient(135deg, #1E3A8A 0%, #1E293B 100%);
        color: white;
        padding: 1.2rem 1.8rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }
    .finance-header h1 {
        color: #FFFFFF !important;
        font-size: 1.8rem;
        font-weight: 700;
        margin: 0;
    }
    .finance-header p {
        color: #93C5FD;
        font-size: 0.95rem;
        margin-top: 0.3rem;
        margin-bottom: 0;
    }
    
    /* KPI Card */
    .metric-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 1rem 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
    }
    .metric-title {
        font-size: 0.82rem;
        font-weight: 600;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #0F172A;
        margin: 0.3rem 0;
    }
    .metric-sub {
        font-size: 0.85rem;
        color: #64748B;
    }
    
    /* Threshold badges */
    .badge-optimal {
        background-color: #DCFCE7;
        color: #166534;
        font-weight: 600;
        padding: 0.2rem 0.55rem;
        border-radius: 9999px;
        font-size: 0.8rem;
    }
    .badge-amber {
        background-color: #FEF3C7;
        color: #92400E;
        font-weight: 600;
        padding: 0.2rem 0.55rem;
        border-radius: 9999px;
        font-size: 0.8rem;
    }
    .badge-red {
        background-color: #FEE2E2;
        color: #991B1B;
        font-weight: 600;
        padding: 0.2rem 0.55rem;
        border-radius: 9999px;
        font-size: 0.8rem;
    }
    .badge-darkred {
        background-color: #FFE4E6;
        color: #9F1239;
        font-weight: 700;
        padding: 0.2rem 0.55rem;
        border-radius: 9999px;
        font-size: 0.8rem;
        border: 1px solid #FDA4AF;
    }
    
    /* Live Utilization Card in Weekly Entry */
    .live-util-card {
        background: #F8FAFC;
        border-radius: 8px;
        padding: 1.2rem;
        border: 2px solid #CBD5E1;
        text-align: center;
    }
    
    /* Section dividers */
    .section-title {
        font-size: 1.2rem;
        font-weight: 600;
        color: #1E293B;
        margin-top: 1.5rem;
        margin-bottom: 0.8rem;
        border-bottom: 2px solid #E2E8F0;
        padding-bottom: 0.4rem;
    }
    </style>
    """, unsafe_allow_html=True)

def render_kpi_card(title: str, value: str, sub: str = "", delta: Optional[str] = None, delta_color: str = "normal"):
    delta_html = ""
    if delta:
        color = "#16A34A" if delta_color == "green" else ("#DC2626" if delta_color == "red" else "#64748B")
        delta_html = f"<span style='color: {color}; font-size: 0.85rem; font-weight: 600;'>{delta}</span>"
    
    html = f"""
    <div class="metric-card">
        <div class="metric-title">{title}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-sub">{sub} {delta_html}</div>
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)

def render_sidebar_filters(session, default_year: str = "2026") -> Dict[str, Any]:
    """
    Render global cascading sidebar filters.
    Returns dictionary with filter values.
    """
    st.sidebar.markdown("### 🔍 Dashboard Filters")
    
    # 1. Year & Basis
    col_yr1, col_yr2 = st.sidebar.columns([1, 1])
    with col_yr1:
        fy_setting = session.query(Setting).filter_by(key="fy_basis").first()
        default_basis = fy_setting.value if fy_setting else "CALENDAR"
        basis = st.selectbox("Basis", ["CALENDAR", "FINANCIAL"], index=0 if default_basis == "CALENDAR" else 1, key="sb_basis")
    with col_yr2:
        if basis == "CALENDAR":
            year_opts = ["2026", "2025", "2024"]
        else:
            year_opts = ["FY2025-26", "FY2024-25"]
        selected_year = st.selectbox("Year", year_opts, index=0, key="sb_year")
    
    # 2. Period Filter
    period_type = st.sidebar.radio(
        "Period Scope",
        ["All Year", "Month", "Quarter", "Custom Weeks"],
        horizontal=True,
        key="sb_period_type"
    )
    
    start_week = None
    end_week = None
    all_year_weeks = get_weeks_for_year(selected_year, basis)
    
    if period_type == "Month":
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        selected_month = st.sidebar.selectbox("Month", months, index=2, key="sb_month") # default Mar
        m_idx = months.index(selected_month) + 1
        year_num = int(selected_year.replace("FY", "").split("-")[0])
        # Find weeks in this month
        month_weeks = [w for w in all_year_weeks if w.month == m_idx or (w + timedelta(days=6)).month == m_idx]
        if month_weeks:
            start_week = month_weeks[0]
            end_week = month_weeks[-1]
            
    elif period_type == "Quarter":
        selected_q = st.sidebar.selectbox("Quarter", ["Q1 (Jan-Mar)", "Q2 (Apr-Jun)", "Q3 (Jul-Sep)", "Q4 (Oct-Dec)"], index=0, key="sb_quarter")
        q_num = int(selected_q[1])
        q_start_month = (q_num - 1) * 3 + 1
        q_end_month = q_num * 3
        q_weeks = [w for w in all_year_weeks if q_start_month <= w.month <= q_end_month]
        if q_weeks:
            start_week = q_weeks[0]
            end_week = q_weeks[-1]
            
    elif period_type == "Custom Weeks":
        week_labels = [format_week_label(w) for w in all_year_weeks]
        w_start_lbl = st.sidebar.selectbox("From Week", week_labels, index=0, key="sb_w_start")
        w_end_lbl = st.sidebar.selectbox("To Week", week_labels, index=min(12, len(week_labels)-1), key="sb_w_end")
        start_idx = week_labels.index(w_start_lbl)
        end_idx = week_labels.index(w_end_lbl)
        if start_idx <= end_idx:
            start_week = all_year_weeks[start_idx]
            end_week = all_year_weeks[end_idx]
        else:
            start_week = all_year_weeks[end_idx]
            end_week = all_year_weeks[start_idx]
            
    # 3. Teams filter
    teams = session.query(Team).filter_by(is_active=True).order_by(Team.name).all()
    team_opts = {t.name: t.id for t in teams}
    sel_teams = st.sidebar.multiselect("Teams", list(team_opts.keys()), default=[], key="sb_teams")
    selected_team_ids = [team_opts[t] for t in sel_teams] if sel_teams else None
    
    # 4. Locations filter
    locations = session.query(Location).order_by(Location.name).all()
    loc_opts = {l.name: l.id for l in locations}
    sel_locs = st.sidebar.multiselect("Locations", list(loc_opts.keys()), default=[], key="sb_locs")
    selected_loc_ids = [loc_opts[l] for l in sel_locs] if sel_locs else None
    
    # 5. Employees filter (cascaded by selected teams)
    user_q = session.query(User).filter_by(is_active=True).filter(User.role != "Admin")
    if selected_loc_ids:
        user_q = user_q.filter(User.location_id.in_(selected_loc_ids))
    users = user_q.order_by(User.name).all()
    emp_opts = {f"{u.name} ({u.emp_id})": u.id for u in users}
    sel_emps = st.sidebar.multiselect("Employees", list(emp_opts.keys()), default=[], key="sb_emps")
    selected_user_ids = [emp_opts[e] for e in sel_emps] if sel_emps else None
    
    # 6. Category BAU vs Value-Add
    cat_type = st.sidebar.selectbox("Category Type", ["All Categories", "BAU Only", "Value-Add Only"], index=0, key="sb_cat_type")
    cat_type_val = "BAU" if cat_type == "BAU Only" else ("VALUE_ADD" if cat_type == "Value-Add Only" else None)
    
    # 7. Category specific filter
    categories = session.query(Category).order_by(Category.sort_order).all()
    cat_opts = {c.name: c.id for c in categories}
    sel_cats = st.sidebar.multiselect("Categories", list(cat_opts.keys()), default=[], key="sb_cats")
    selected_cat_ids = [cat_opts[c] for c in sel_cats] if sel_cats else None

    filters_summary = {
        "Year": selected_year,
        "Basis": basis,
        "Period": period_type if period_type != "Custom Weeks" else f"{start_week} to {end_week}",
        "Teams": ", ".join(sel_teams) if sel_teams else "All Teams",
        "Locations": ", ".join(sel_locs) if sel_locs else "All Locations",
        "Employees": f"{len(sel_emps)} selected" if sel_emps else "All Employees",
        "Category Type": cat_type,
        "Categories": ", ".join(sel_cats) if sel_cats else "All 9 Categories"
    }

    return {
        "year_str": selected_year,
        "fy_basis": basis,
        "start_week": start_week,
        "end_week": end_week,
        "team_ids": selected_team_ids,
        "user_ids": selected_user_ids,
        "location_ids": selected_loc_ids,
        "category_ids": selected_cat_ids,
        "cat_type_filter": cat_type_val,
        "filters_summary": filters_summary
    }
