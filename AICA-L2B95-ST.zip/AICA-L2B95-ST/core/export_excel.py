import io
from datetime import datetime, date
from typing import List, Dict, Any, Optional
import pandas as pd
import xlsxwriter

def create_utilization_excel_workbook(
    summary_data: Dict[str, Any],
    raw_records: List[Dict[str, Any]],
    employee_weekly_df: pd.DataFrame,
    employee_monthly_df: pd.DataFrame,
    employee_yearly_df: pd.DataFrame,
    team_cat_matrix_df: pd.DataFrame,
    cat_analysis_df: pd.DataFrame,
    leave_exclusions_df: pd.DataFrame,
    exceptions_df: pd.DataFrame,
    filters_info: Dict[str, str]
) -> io.BytesIO:
    """
    Generate the complete 8-sheet professional Excel workbook with XlsxWriter.
    """
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output, {'in_memory': True, 'remove_timezone': True})

    # Color palette
    NAVY = "#1E3A8A"
    LIGHT_BG = "#F8FAFC"
    BORDER_COLOR = "#CBD5E1"
    GREEN_FILL = "#DCFCE7"
    GREEN_TEXT = "#166534"
    AMBER_FILL = "#FEF3C7"
    AMBER_TEXT = "#92400E"
    RED_FILL = "#FEE2E2"
    RED_TEXT = "#991B1B"
    PURPLE_FILL = "#F3E8FF"
    PURPLE_TEXT = "#6B21A8"

    # Formats
    title_fmt = workbook.add_format({
        'bold': True, 'font_size': 16, 'font_color': '#FFFFFF',
        'bg_color': NAVY, 'align': 'left', 'valign': 'vcenter', 'left': 1, 'top': 1, 'right': 1, 'bottom': 1
    })
    subtitle_fmt = workbook.add_format({
        'font_size': 10, 'font_color': '#64748B', 'italic': True
    })
    header_fmt = workbook.add_format({
        'bold': True, 'font_size': 11, 'font_color': '#FFFFFF',
        'bg_color': NAVY, 'align': 'center', 'valign': 'vcenter',
        'border': 1, 'text_wrap': True
    })
    sub_header_fmt = workbook.add_format({
        'bold': True, 'font_size': 11, 'font_color': '#1E293B',
        'bg_color': '#E2E8F0', 'align': 'left', 'valign': 'vcenter', 'border': 1
    })
    cell_fmt = workbook.add_format({'font_size': 10, 'border': 1, 'valign': 'vcenter'})
    cell_center = workbook.add_format({'font_size': 10, 'align': 'center', 'border': 1, 'valign': 'vcenter'})
    num_fmt = workbook.add_format({'font_size': 10, 'num_format': '#,##0.00', 'border': 1, 'align': 'right'})
    pct_fmt = workbook.add_format({'font_size': 10, 'num_format': '0.0%', 'border': 1, 'align': 'right'})
    kpi_val_fmt = workbook.add_format({
        'bold': True, 'font_size': 14, 'align': 'center', 'border': 1, 'bg_color': '#F1F5F9', 'num_format': '#,##0.00'
    })
    kpi_pct_fmt = workbook.add_format({
        'bold': True, 'font_size': 14, 'align': 'center', 'border': 1, 'bg_color': '#F1F5F9', 'num_format': '0.0%'
    })
    kpi_lbl_fmt = workbook.add_format({
        'bold': True, 'font_size': 9, 'align': 'center', 'border': 1, 'bg_color': '#E2E8F0', 'font_color': '#475569'
    })

    # Conditional formatting color scales
    cf_optimal = workbook.add_format({'bg_color': GREEN_FILL, 'font_color': GREEN_TEXT})
    cf_amber = workbook.add_format({'bg_color': AMBER_FILL, 'font_color': AMBER_TEXT})
    cf_under = workbook.add_format({'bg_color': RED_FILL, 'font_color': RED_TEXT})
    cf_burnout = workbook.add_format({'bg_color': '#FFE4E6', 'font_color': '#9F1239', 'bold': True})

    # ==========================================
    # 1. SUMMARY SHEET
    # ==========================================
    ws_sum = workbook.add_worksheet('Summary')
    ws_sum.set_tab_color('#1E3A8A')
    ws_sum.freeze_panes(5, 0)
    ws_sum.set_column('A:A', 28)
    ws_sum.set_column('B:B', 30)
    ws_sum.set_column('C:C', 20)
    ws_sum.set_column('D:D', 20)
    ws_sum.set_column('E:E', 25)

    ws_sum.merge_range('A1:E1', '  Finance Team Utilization Tracker — Executive Summary', title_fmt)
    ws_sum.write('A2', f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", subtitle_fmt)

    # Active Filters
    ws_sum.write('A4', 'Filter Parameters', sub_header_fmt)
    ws_sum.write('B4', 'Value', sub_header_fmt)
    row = 4
    for k, v in filters_info.items():
        ws_sum.write(row, 0, k, cell_fmt)
        ws_sum.write(row, 1, str(v), cell_fmt)
        row += 1

    # KPI Block
    row += 2
    ws_sum.merge_range(row, 0, row, 4, 'Executive KPIs (Hours-Weighted)', sub_header_fmt)
    row += 1

    kpis = [
        ('Utilization %', summary_data.get('utilization_pct', 0) / 100.0 if summary_data.get('utilization_pct') else 0, kpi_pct_fmt),
        ('Target Util %', summary_data.get('target_util_pct', 85) / 100.0, kpi_pct_fmt),
        ('Total Logged (Hrs)', summary_data.get('total_logged_hours', 0), kpi_val_fmt),
        ('Total Available (Hrs)', summary_data.get('total_available_hours', 0), kpi_val_fmt),
        ('Capacity Gap (Hrs)', summary_data.get('capacity_gap', 0), kpi_val_fmt),
    ]

    for col_idx, (lbl, val, fmt) in enumerate(kpis):
        ws_sum.write(row, col_idx, lbl, kpi_lbl_fmt)
        ws_sum.write(row + 1, col_idx, val, fmt)

    row += 4
    ws_sum.merge_range(row, 0, row, 4, 'Core Formula Definitions & Governing Rules', sub_header_fmt)
    row += 1
    definitions = [
        ("Standard Daily Hours", "7.5 hours/day standard working day baseline."),
        ("Available Hours (Week)", "= (Working Days [Mon-Fri less Location Holidays] - Total Leave Days) × 7.5"),
        ("Weekly Utilization %", "= Total Logged Hours ÷ Available Hours × 100 (Uncapped, live calculated)"),
        ("Excluded Week Rule", "Full-week leave, maternity, sabbatical or leave ≥ working days drops week entirely from numerator and denominator."),
        ("Hours-Weighted Aggregation", "= Σ Logged Hours ÷ Σ Available Hours (Never average of percentages)."),
        ("Threshold Bands", "<70% Under-utilized; 70-85% Below Target; 85-100% Optimal; >100% Burnout Overload (Watch 100-110%, High 110-120%, Critical >120%)."),
    ]
    for def_title, def_desc in definitions:
        ws_sum.write(row, 0, def_title, cell_fmt)
        ws_sum.merge_range(row, 1, row, 4, def_desc, cell_fmt)
        row += 1

    # ==========================================
    # 2. RAW_DATA SHEET
    # ==========================================
    ws_raw = workbook.add_worksheet('Raw_Data')
    ws_raw.freeze_panes(1, 0)
    raw_cols = ['Employee ID', 'Employee Name', 'Team', 'Week Starting', 'Category', 'Category Type', 'Logged Hours', 'Available Hours', 'Leave Type', 'Leave Days', 'Is Excluded']
    for c_idx, c_name in enumerate(raw_cols):
        ws_raw.write(0, c_idx, c_name, header_fmt)

    for r_idx, rec in enumerate(raw_records, start=1):
        ws_raw.write(r_idx, 0, rec.get('emp_id', ''), cell_center)
        ws_raw.write(r_idx, 1, rec.get('emp_name', ''), cell_fmt)
        ws_raw.write(r_idx, 2, rec.get('team', ''), cell_fmt)
        ws_raw.write(r_idx, 3, str(rec.get('week_start', '')), cell_center)
        ws_raw.write(r_idx, 4, rec.get('category', ''), cell_fmt)
        ws_raw.write(r_idx, 5, rec.get('category_type', 'BAU'), cell_center)
        ws_raw.write(r_idx, 6, rec.get('logged_hours', 0.0), num_fmt)
        ws_raw.write(r_idx, 7, rec.get('available_hours', 0.0), num_fmt)
        ws_raw.write(r_idx, 8, rec.get('leave_type', ''), cell_fmt)
        ws_raw.write(r_idx, 9, rec.get('leave_days', 0.0), num_fmt)
        ws_raw.write(r_idx, 10, 'Yes' if rec.get('is_excluded') else 'No', cell_center)

    ws_raw.set_column('A:A', 14)
    ws_raw.set_column('B:B', 24)
    ws_raw.set_column('C:C', 20)
    ws_raw.set_column('D:D', 14)
    ws_raw.set_column('E:E', 30)
    ws_raw.set_column('F:F', 14)
    ws_raw.set_column('G:J', 14)
    ws_raw.set_column('K:K', 12)

    # ==========================================
    # 3. EMPLOYEE_WEEKLY SHEET
    # ==========================================
    ws_ew = workbook.add_worksheet('Employee_Weekly')
    ws_ew.freeze_panes(1, 2)
    _write_df_to_worksheet(workbook, ws_ew, employee_weekly_df, header_fmt, cell_fmt, num_fmt, pct_fmt, apply_util_cf=True)

    # ==========================================
    # 4. EMPLOYEE_MONTHLY & YEARLY
    # ==========================================
    ws_em = workbook.add_worksheet('Employee_Monthly')
    ws_em.freeze_panes(1, 2)
    _write_df_to_worksheet(workbook, ws_em, employee_monthly_df, header_fmt, cell_fmt, num_fmt, pct_fmt, apply_util_cf=True)

    ws_ey = workbook.add_worksheet('Employee_Yearly')
    ws_ey.freeze_panes(1, 2)
    _write_df_to_worksheet(workbook, ws_ey, employee_yearly_df, header_fmt, cell_fmt, num_fmt, pct_fmt, apply_util_cf=True)

    # ==========================================
    # 5. TEAM_CATEGORY_MATRIX
    # ==========================================
    ws_tc = workbook.add_worksheet('Team_Category_Matrix')
    ws_tc.freeze_panes(1, 1)
    _write_df_to_worksheet(workbook, ws_tc, team_cat_matrix_df, header_fmt, cell_fmt, num_fmt, pct_fmt)

    # ==========================================
    # 6. CATEGORY_ANALYSIS
    # ==========================================
    ws_ca = workbook.add_worksheet('Category_Analysis')
    ws_ca.freeze_panes(1, 1)
    _write_df_to_worksheet(workbook, ws_ca, cat_analysis_df, header_fmt, cell_fmt, num_fmt, pct_fmt)

    # ==========================================
    # 7. LEAVE_EXCLUSIONS
    # ==========================================
    ws_le = workbook.add_worksheet('Leave_Exclusions')
    ws_le.freeze_panes(1, 0)
    _write_df_to_worksheet(workbook, ws_le, leave_exclusions_df, header_fmt, cell_fmt, num_fmt, pct_fmt)

    # ==========================================
    # 8. EXCEPTIONS
    # ==========================================
    ws_ex = workbook.add_worksheet('Exceptions')
    ws_ex.freeze_panes(1, 0)
    _write_df_to_worksheet(workbook, ws_ex, exceptions_df, header_fmt, cell_fmt, num_fmt, pct_fmt)

    workbook.close()
    output.seek(0)
    return output

def _write_df_to_worksheet(
    workbook, ws, df: pd.DataFrame, header_fmt, cell_fmt, num_fmt, pct_fmt, apply_util_cf: bool = False
):
    """Helper to write DataFrame to an XlsxWriter worksheet with auto-width and conditional formatting."""
    if df is None or df.empty:
        ws.write(0, 0, "No data available for the selected filters.", cell_fmt)
        return

    # Write headers
    for c_idx, col in enumerate(df.columns):
        ws.write(0, c_idx, str(col), header_fmt)

    # Write rows
    for r_idx, row_vals in enumerate(df.values, start=1):
        for c_idx, val in enumerate(row_vals):
            col_name = str(df.columns[c_idx]).lower()
            if pd.isna(val) or val is None:
                ws.write(r_idx, c_idx, "-", cell_fmt)
            elif isinstance(val, (int, float)):
                if "%" in col_name or "pct" in col_name or "utilization" in col_name or "mix" in col_name:
                    # If value > 1 (e.g. 85.5 meaning 85.5%), convert to 0.855 for Excel % format
                    excel_pct = val / 100.0 if abs(val) > 1.0 else val
                    ws.write(r_idx, c_idx, excel_pct, pct_fmt)
                else:
                    ws.write(r_idx, c_idx, val, num_fmt)
            else:
                ws.write(r_idx, c_idx, str(val), cell_fmt)

    # Auto-fit column widths
    for c_idx, col in enumerate(df.columns):
        max_len = max(len(str(col)), max([len(str(x)) for x in df[col].dropna()[:50]] or [0])) + 3
        ws.set_column(c_idx, c_idx, min(max(max_len, 12), 40))

    # Conditional formatting on utilization % columns
    if apply_util_cf:
        for c_idx, col in enumerate(df.columns):
            col_str = str(col).lower()
            if "util" in col_str or "w" in col_str or "jan" in col_str or "feb" in col_str or "mar" in col_str:
                num_rows = len(df)
                if num_rows > 0:
                    # Under-utilized < 70% (0.70)
                    ws.conditional_format(1, c_idx, num_rows, c_idx, {
                        'type': 'cell', 'criteria': '<', 'value': 0.70,
                        'format': workbook.add_format({'bg_color': '#FEE2E2', 'font_color': '#991B1B'})
                    })
                    # Optimal 85% to 100% (0.85 to 1.00)
                    ws.conditional_format(1, c_idx, num_rows, c_idx, {
                        'type': 'cell', 'criteria': 'between', 'minimum': 0.85, 'maximum': 1.00,
                        'format': workbook.add_format({'bg_color': '#DCFCE7', 'font_color': '#166534'})
                    })
                    # Overloaded > 100% (1.00)
                    ws.conditional_format(1, c_idx, num_rows, c_idx, {
                        'type': 'cell', 'criteria': '>', 'value': 1.00,
                        'format': workbook.add_format({'bg_color': '#FFE4E6', 'font_color': '#9F1239', 'bold': True})
                    })

def generate_blank_employee_import_template() -> io.BytesIO:
    """Generate sample template for bulk employee upload."""
    output = io.BytesIO()
    wb = xlsxwriter.Workbook(output, {'in_memory': True})
    ws = wb.add_worksheet("Employee_Master_Template")

    headers = [
        "Employee ID *", "Full Name *", "Email *", "Role (Employee/Team Lead/Manager/Director/Admin) *",
        "Primary Team Name *", "Secondary Team Name", "Location (e.g. India - Gurugram) *",
        "Join Date (YYYY-MM-DD)", "Exit Date (YYYY-MM-DD)", "Active (TRUE/FALSE)"
    ]
    hdr_fmt = wb.add_format({'bold': True, 'bg_color': '#1E3A8A', 'font_color': '#FFFFFF', 'border': 1})
    ws.set_column('A:J', 24)
    for c, h in enumerate(headers):
        ws.write(0, c, h, hdr_fmt)

    sample_row = [
        "EMP101", "Alex Morgan", "alex.morgan@finance.org", "Employee",
        "Record-to-Report", "Intercompany & Controls", "India - Gurugram",
        "2024-01-15", "", "TRUE"
    ]
    for c, val in enumerate(sample_row):
        ws.write(1, c, val)

    wb.close()
    output.seek(0)
    return output

def generate_blank_hours_import_template() -> io.BytesIO:
    """Generate sample template for bulk historical hours upload."""
    output = io.BytesIO()
    wb = xlsxwriter.Workbook(output, {'in_memory': True})
    ws = wb.add_worksheet("Hours_Upload_Template")

    headers = [
        "Employee ID *", "Week Start Monday (YYYY-MM-DD) *", "Team Name *",
        "Category Code (CLOSE/REPORTING/RECON/INTERCO/AUDIT/CI_AUTO/GOVERNANCE/ADHOC/FPNA) *",
        "Logged Hours *"
    ]
    hdr_fmt = wb.add_format({'bold': True, 'bg_color': '#1E3A8A', 'font_color': '#FFFFFF', 'border': 1})
    ws.set_column('A:E', 28)
    for c, h in enumerate(headers):
        ws.write(0, c, h, hdr_fmt)

    sample_row = ["EMP101", "2026-01-05", "Record-to-Report", "CLOSE", 25.5]
    for c, val in enumerate(sample_row):
        ws.write(1, c, val)

    wb.close()
    output.seek(0)
    return output
