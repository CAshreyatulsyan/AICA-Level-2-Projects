import random
from datetime import date, timedelta, datetime
from sqlalchemy.orm import Session
from core.db import (
    SessionLocal, User, Team, UserTeam, Category, LeaveType, Location,
    Holiday, WeeklyEntry, WeeklyLeave, WeeklyHours, Target, AutomationSaving, Setting
)
from core.auth import hash_password
from core.calendar import get_monday, get_weeks_for_year

TEAMS_CONFIG = [
    ("Record-to-Report", "Record-to-Report", "CC-101", "Priya Sharma", "priya.sharma@finance.org", "Team Lead"),
    ("Financial Reporting & BPC", "Group Reporting", "CC-102", "Rajesh Verma", "rajesh.verma@finance.org", "Team Lead"),
    ("FP&A & Commercial Finance", "Financial Planning", "CC-103", "Ananya Iyer", "ananya.iyer@finance.org", "Team Lead"),
    ("Intercompany & Controls", "Controllership & Audit", "CC-104", "David Chen", "david.chen@finance.org", "Team Lead"),
]

DIRECTOR_USER = ("EMP002", "Vikram Malhotra", "vikram.malhotra@finance.org", "Director", "India - Gurugram")

EMPLOYEES_CONFIG = [
    # Team 1: Record-to-Report (Lead + 6 staff)
    ("EMP010", "Aarav Patel", "aarav.patel@finance.org", "Employee", "India - Gurugram", "Record-to-Report", "Intercompany & Controls"),
    ("EMP011", "Neha Gupta", "neha.gupta@finance.org", "Employee", "India - Gurugram", "Record-to-Report", None),
    ("EMP012", "Rohan Mehta", "rohan.mehta@finance.org", "Employee", "India - Kolkata", "Record-to-Report", None),
    ("EMP013", "Sneha Kulkarni", "sneha.kulkarni@finance.org", "Employee", "India - Gurugram", "Record-to-Report", None),
    ("EMP014", "Vikash Sen", "vikash.sen@finance.org", "Employee", "India - Kolkata", "Record-to-Report", None),
    ("EMP015", "James Taylor", "james.taylor@finance.org", "Employee", "UK - London", "Record-to-Report", "Financial Reporting & BPC"),

    # Team 2: Financial Reporting & BPC (Lead + 5 staff)
    ("EMP020", "Pooja Reddy", "pooja.reddy@finance.org", "Employee", "India - Gurugram", "Financial Reporting & BPC", None),
    ("EMP021", "Aditya Nair", "aditya.nair@finance.org", "Employee", "India - Gurugram", "Financial Reporting & BPC", "Record-to-Report"),
    ("EMP022", "Kavita Rao", "kavita.rao@finance.org", "Employee", "India - Kolkata", "Financial Reporting & BPC", None),
    ("EMP023", "Amit Roy", "amit.roy@finance.org", "Employee", "India - Kolkata", "Financial Reporting & BPC", None),
    ("EMP024", "Oliver Smith", "oliver.smith@finance.org", "Employee", "UK - London", "Financial Reporting & BPC", None),

    # Team 3: FP&A & Commercial Finance (Lead + 5 staff)
    ("EMP030", "Deepak Joshi", "deepak.joshi@finance.org", "Employee", "India - Gurugram", "FP&A & Commercial Finance", None),
    ("EMP031", "Ishita Bose", "ishita.bose@finance.org", "Employee", "India - Kolkata", "FP&A & Commercial Finance", None),
    ("EMP032", "Manish Saxena", "manish.saxena@finance.org", "Employee", "India - Gurugram", "FP&A & Commercial Finance", None),
    ("EMP033", "Ritu Sengupta", "ritu.sengupta@finance.org", "Employee", "India - Kolkata", "FP&A & Commercial Finance", None),
    ("EMP034", "Sarah Jenkins", "sarah.jenkins@finance.org", "Employee", "US - New York", "FP&A & Commercial Finance", None),

    # Team 4: Intercompany & Controls (Lead + 5 staff)
    ("EMP040", "Sunil Das", "sunil.das@finance.org", "Employee", "India - Kolkata", "Intercompany & Controls", "Record-to-Report"),
    ("EMP041", "Divya Menon", "divya.menon@finance.org", "Employee", "India - Gurugram", "Intercompany & Controls", None),
    ("EMP042", "Karan Singhal", "karan.singhal@finance.org", "Employee", "India - Gurugram", "Intercompany & Controls", None),
    ("EMP043", "Swati Mukherjee", "swati.mukherjee@finance.org", "Employee", "India - Kolkata", "Intercompany & Controls", None),
    ("EMP044", "Michael Brown", "michael.brown@finance.org", "Employee", "US - New York", "Intercompany & Controls", None),
]

def seed_demo_data(session: Session = None):
    """Seed comprehensive realistic demo data for 4 teams, 25+ users, 52 weeks."""
    close_session = False
    if session is None:
        session = SessionLocal()
        close_session = True

    try:
        # Check if demo data already seeded
        existing_demo = session.query(User).filter(User.emp_id.in_(["EMP002", "EMP010"])).first()
        if existing_demo:
            return {"status": "already_seeded", "message": "Demo data already exists in database."}

        default_pw_hash = hash_password("demo123")

        # 1. Locations
        loc_map = {loc.name: loc.id for loc in session.query(Location).all()}

        # 2. Director User
        dir_loc_id = loc_map.get(DIRECTOR_USER[4])
        director = User(
            emp_id=DIRECTOR_USER[0],
            name=DIRECTOR_USER[1],
            email=DIRECTOR_USER[2],
            role=DIRECTOR_USER[3],
            password_hash=default_pw_hash,
            location_id=dir_loc_id,
            join_date=date(2023, 1, 1),
            is_active=True,
            must_change_pw=False
        )
        session.add(director)
        session.commit()

        # 3. Teams & Leads
        team_map = {}
        for idx, (t_name, func, cc, lead_name, lead_email, role) in enumerate(TEAMS_CONFIG, start=3):
            emp_id = f"EMP00{idx}"
            lead_user = session.query(User).filter_by(emp_id=emp_id).first()
            if not lead_user:
                lead_user = User(
                    emp_id=emp_id,
                    name=lead_name,
                    email=lead_email,
                    role=role,
                    password_hash=default_pw_hash,
                    location_id=loc_map.get("India - Gurugram"),
                    join_date=date(2023, 6, 1),
                    is_active=True,
                    must_change_pw=False
                )
                session.add(lead_user)
                session.commit()

            team = session.query(Team).filter_by(name=t_name).first()
            if not team:
                team = Team(
                    name=t_name,
                    lead_user_id=lead_user.id,
                    function=func,
                    cost_centre=cc,
                    is_active=True
                )
                session.add(team)
                session.commit()
            team_map[t_name] = team.id

            # Associate Lead with Team
            if not session.query(UserTeam).filter_by(user_id=lead_user.id, team_id=team.id).first():
                session.add(UserTeam(user_id=lead_user.id, team_id=team.id, is_primary=True))
                session.commit()

        # 4. Employees & Team Assignments
        all_created_users = []
        for emp_id, name, email, role, loc_str, primary_team, sec_team in EMPLOYEES_CONFIG:
            u = session.query(User).filter_by(emp_id=emp_id).first()
            if not u:
                u = User(
                    emp_id=emp_id,
                    name=name,
                    email=email,
                    role=role,
                    password_hash=default_pw_hash,
                    location_id=loc_map.get(loc_str, list(loc_map.values())[0]),
                    join_date=date(2024, 1, 1),
                    is_active=True,
                    must_change_pw=False
                )
                session.add(u)
                session.commit()

            all_created_users.append((u, primary_team, sec_team))

            t_id = team_map.get(primary_team)
            if t_id and not session.query(UserTeam).filter_by(user_id=u.id, team_id=t_id).first():
                session.add(UserTeam(user_id=u.id, team_id=t_id, is_primary=True))

            if sec_team and sec_team in team_map:
                sec_t_id = team_map[sec_team]
                if not session.query(UserTeam).filter_by(user_id=u.id, team_id=sec_t_id).first():
                    session.add(UserTeam(user_id=u.id, team_id=sec_t_id, is_primary=False))

        session.commit()

        # 5. Targets (Set target mix % per category per team)
        categories = {c.code: c.id for c in session.query(Category).all()}
        for t_name, t_id in team_map.items():
            # Standard targets
            target_configs = [
                ("CLOSE", 30.0),
                ("REPORTING", 20.0),
                ("RECON", 15.0),
                ("INTERCO", 10.0),
                ("AUDIT", 5.0),
                ("CI_AUTO", 10.0),
                ("GOVERNANCE", 5.0),
                ("ADHOC", 3.0),
                ("FPNA", 2.0),
            ]
            for c_code, mix_pct in target_configs:
                c_id = categories.get(c_code)
                if c_id and not session.query(Target).filter_by(team_id=t_id, category_id=c_id).first():
                    session.add(Target(
                        team_id=t_id,
                        category_id=c_id,
                        target_mix_pct=mix_pct,
                        target_util_pct=85.0,
                        fy="2026"
                    ))
        session.commit()

        # 6. Automation Savings (ROI tracking for Director dashboard)
        for m in ["2025-10", "2025-11", "2025-12", "2026-01", "2026-02", "2026-03"]:
            for t_id in list(team_map.values())[:2]:
                if not session.query(AutomationSaving).filter_by(month_year=m, team_id=t_id).first():
                    session.add(AutomationSaving(
                        month_year=m,
                        team_id=t_id,
                        hours_saved=random.choice([45.0, 60.0, 85.0, 110.0]),
                        description="PowerQuery SAP reconciliations & Alteryx journal automated feed"
                    ))
        session.commit()

        # 7. Generate 52 Weeks of Historical Entries for all employees
        leave_types = {lt.name: lt for lt in session.query(LeaveType).all()}
        mat_leave_type = next((lt for lt in leave_types.values() if "Maternity" in lt.name), None)
        sab_leave_type = next((lt for lt in leave_types.values() if "Sabbatical" in lt.name), None)
        sick_leave_type = next((lt for lt in leave_types.values() if "Casual" in lt.name or "Sick" in lt.name), None)

        all_weeks = sorted(list(set(get_weeks_for_year("2025", "CALENDAR") + get_weeks_for_year("2026", "CALENDAR")[:14])))
        # Keep 52 weeks total
        weeks_52 = all_weeks[-52:]

        # Select special employees for maternity, sabbatical, and burnout patterns
        maternity_emp_id = "EMP011"  # Neha Gupta
        sabbatical_emp_id = "EMP022"  # Kavita Rao
        burnout_emp_1 = "EMP010"     # Aarav Patel (Heavy R2R peak worker)
        burnout_emp_2 = "EMP020"     # Pooja Reddy (Reporting overload)

        for u, pri_team_name, sec_team_name in all_created_users:
            pri_team_id = team_map[pri_team_name]
            sec_team_id = team_map[sec_team_name] if sec_team_name else None

            for w_idx, w_start in enumerate(weeks_52):
                # Check special exclusion cases
                is_maternity_week = (u.emp_id == maternity_emp_id and 15 <= w_idx <= 26) # 12 weeks
                is_sabbatical_week = (u.emp_id == sabbatical_emp_id and 30 <= w_idx <= 37) # 8 weeks
                is_casual_leave_week = (random.random() < 0.08) # 8% chance of 1-2 days casual leave

                entry = WeeklyEntry(
                    user_id=u.id,
                    week_start=w_start,
                    status="Submitted",
                    comment="Month-end close & statutory audit deliverable" if (w_idx % 4 == 0) else None,
                    submitted_at=datetime.combine(w_start + timedelta(days=6), datetime.min.time()),
                    locked=(w_idx < 45) # older weeks locked
                )
                session.add(entry)
                session.flush()

                # Leaves
                if is_maternity_week and mat_leave_type:
                    session.add(WeeklyLeave(entry_id=entry.id, leave_type_id=mat_leave_type.id, days=5.0))
                    continue  # No logged hours in full maternity week

                if is_sabbatical_week and sab_leave_type:
                    session.add(WeeklyLeave(entry_id=entry.id, leave_type_id=sab_leave_type.id, days=5.0))
                    continue  # No logged hours in sabbatical week

                leave_days_entered = 0.0
                if is_casual_leave_week and sick_leave_type:
                    l_days = random.choice([1.0, 2.0])
                    leave_days_entered = l_days
                    session.add(WeeklyLeave(entry_id=entry.id, leave_type_id=sick_leave_type.id, days=l_days))

                # Determine hours profile based on close cycle vs normal week
                # Close cycle occurs typically week of month-end or first week of month
                is_close_week = (w_start.day >= 26 or w_start.day <= 6)
                is_quarter_end = is_close_week and (w_start.month in [3, 6, 9, 12])

                # Determine target hours
                base_hrs = 37.5 - (leave_days_entered * 7.5)
                if base_hrs <= 0:
                    continue

                if u.emp_id in [burnout_emp_1, burnout_emp_2] and (is_close_week or is_quarter_end):
                    # Deliberately push into burnout (>100%, 110-135%)
                    target_total = base_hrs * random.uniform(1.12, 1.38)
                elif is_close_week:
                    target_total = base_hrs * random.uniform(0.95, 1.15)
                else:
                    target_total = base_hrs * random.uniform(0.72, 0.98)

                target_total = round(target_total * 4) / 4.0  # round to 0.25

                # Distribute target_total across categories
                # Categories: 1:CLOSE, 2:REPORTING, 3:RECON, 4:INTERCO, 5:AUDIT, 6:CI_AUTO, 7:GOVERNANCE, 8:ADHOC, 9:FPNA
                if is_close_week:
                    # Heavy in CLOSE & REPORTING
                    weights = [0.45, 0.25, 0.12, 0.08, 0.03, 0.03, 0.02, 0.01, 0.01]
                else:
                    # Spread evenly across RECON, INTERCO, CI_AUTO, GOVERNANCE, AUDIT
                    weights = [0.10, 0.10, 0.25, 0.15, 0.10, 0.12, 0.08, 0.05, 0.05]

                # Secondary team split if applicable
                split_sec = (sec_team_id is not None and random.random() < 0.40)
                sec_ratio = 0.25 if split_sec else 0.0

                for cat_code, w in zip(["CLOSE", "REPORTING", "RECON", "INTERCO", "AUDIT", "CI_AUTO", "GOVERNANCE", "ADHOC", "FPNA"], weights):
                    cat_id = categories.get(cat_code)
                    cat_hrs = round(target_total * w * 4) / 4.0
                    if cat_hrs <= 0:
                        continue

                    if split_sec and sec_team_id and cat_code in ["RECON", "INTERCO", "CI_AUTO"]:
                        hrs_sec = round(cat_hrs * sec_ratio * 4) / 4.0
                        hrs_pri = cat_hrs - hrs_sec
                        if hrs_pri > 0:
                            session.add(WeeklyHours(entry_id=entry.id, team_id=pri_team_id, category_id=cat_id, hours=hrs_pri))
                        if hrs_sec > 0:
                            session.add(WeeklyHours(entry_id=entry.id, team_id=sec_team_id, category_id=cat_id, hours=hrs_sec))
                    else:
                        session.add(WeeklyHours(entry_id=entry.id, team_id=pri_team_id, category_id=cat_id, hours=cat_hrs))

        session.commit()
        return {"status": "success", "message": "Successfully seeded realistic demo dataset (4 teams, 25 employees, 52 weeks, close cycles, maternity, burnout cases)."}
    except Exception as e:
        session.rollback()
        raise e
    finally:
        if close_session:
            session.close()

def clear_demo_data(session: Session = None):
    """Remove all demo entries and users, restoring database to clean initial state."""
    close_session = False
    if session is None:
        session = SessionLocal()
        close_session = True

    try:
        # Delete demo users (keep EMP001 admin)
        demo_users = session.query(User).filter(User.emp_id != "EMP001").all()
        for u in demo_users:
            session.delete(u)

        # Delete teams and targets
        session.query(WeeklyHours).delete()
        session.query(WeeklyLeave).delete()
        session.query(WeeklyEntry).delete()
        session.query(Target).delete()
        session.query(AutomationSaving).delete()
        session.query(UserTeam).delete()
        session.query(Team).delete()

        session.commit()
        return {"status": "success", "message": "Demo data successfully wiped. System returned to clean baseline state."}
    except Exception as e:
        session.rollback()
        raise e
    finally:
        if close_session:
            session.close()
