from typing import List, Dict, Any, Optional

def generate_insights(
    aggregated_metrics: Dict[str, Any],
    team_names: Dict[int, str],
    category_names: Dict[int, str],
    category_types: Dict[int, str],
    prior_period_metrics: Optional[Dict[str, Any]] = None,
    burnout_details: Optional[List[Dict[str, Any]]] = None,
    close_cycle_share: Optional[float] = None
) -> List[str]:
    """
    Generate 5 to 8 rule-based executive insights in plain English.
    No external AI API calls. Deterministic and finance-focused.
    """
    insights: List[str] = []

    overall_util = aggregated_metrics.get("utilization_pct")
    target_util = aggregated_metrics.get("target_util_pct", 85.0)
    variance = aggregated_metrics.get("variance_vs_target")
    total_logged = aggregated_metrics.get("total_logged_hours", 0.0)
    total_avail = aggregated_metrics.get("total_available_hours", 0.0)
    burnout_weeks = aggregated_metrics.get("burnout_weeks_count", 0)
    team_metrics = aggregated_metrics.get("team_metrics", {})
    cat_metrics = aggregated_metrics.get("category_metrics", {})

    # 1. Overall Team / Org Utilization vs Target
    if overall_util is not None:
        if variance is not None:
            direction = "above" if variance > 0 else "below"
            status = "over-capacity" if overall_util > 100.0 else ("on target" if abs(variance) <= 3 else "off target")
            insights.append(
                f"Overall utilization closed at **{overall_util:.1f}%** ({abs(variance):.1f} pts {direction} the {target_util:.0f}% target), logging **{total_logged:,.1f} hrs** against **{total_avail:,.1f} available hrs**."
            )
        else:
            insights.append(f"Overall utilization reached **{overall_util:.1f}%** across {total_logged:,.1f} logged hours.")

    # 2. Team-level peaks & variance
    if team_metrics:
        sorted_teams = sorted(
            [(t_id, data) for t_id, data in team_metrics.items() if data.get("utilization_pct") is not None],
            key=lambda x: x[1]["utilization_pct"],
            reverse=True
        )
        if sorted_teams:
            highest_t_id, highest_data = sorted_teams[0]
            highest_name = team_names.get(highest_t_id, f"Team {highest_t_id}")
            h_util = highest_data["utilization_pct"]
            h_var = h_util - target_util
            insights.append(
                f"**{highest_name}** recorded the highest operational pressure at **{h_util:.1f}%** ({h_var:+.1f} pts vs target), accounting for **{highest_data['logged']:,.1f} logged hours**."
            )

        if len(sorted_teams) > 1:
            lowest_t_id, lowest_data = sorted_teams[-1]
            lowest_name = team_names.get(lowest_t_id, f"Team {lowest_t_id}")
            l_util = lowest_data["utilization_pct"]
            if l_util < 70.0:
                insights.append(
                    f"**{lowest_name}** operated in the under-utilized band at **{l_util:.1f}%** ({target_util - l_util:.1f} pts slack), presenting redeployment or cross-skilling capacity."
                )

    # 3. Burnout & Attrition Risk
    if burnout_details:
        total_flagged_emps = len(burnout_details)
        critical_count = sum(1 for e in burnout_details if e.get("peak_utilization", 0) > 120.0)
        streaks_ge_4 = sum(1 for e in burnout_details if e.get("consecutive_streak", 0) >= 4)
        streaks_ge_2 = sum(1 for e in burnout_details if e.get("consecutive_streak", 0) >= 2)

        if total_flagged_emps > 0:
            if streaks_ge_4 > 0:
                streak_msg = f", with **{streaks_ge_4} employees** sustaining overload for 4+ consecutive weeks"
            elif streaks_ge_2 > 0:
                streak_msg = f", with **{streaks_ge_2} employees** exceeding 100% for 2+ consecutive weeks"
            else:
                streak_msg = ""
            insights.append(
                f"**{total_flagged_emps} employees** breached 100% weekly utilization{streak_msg} (**{critical_count} critical** >120%), signaling localized attrition and fatigue risk."
            )
    elif burnout_weeks > 0:
        insights.append(
            f"**{burnout_weeks} employee-weeks** exceeded 100% capacity threshold during the selected timeframe."
        )

    # 4. BAU vs Value-Add Portfolio Balance
    bau_hours = 0.0
    val_hours = 0.0
    for c_id, c_data in cat_metrics.items():
        c_type = category_types.get(c_id, "BAU")
        if c_type == "BAU":
            bau_hours += c_data.get("hours", 0.0)
        else:
            val_hours += c_data.get("hours", 0.0)

    total_cat_hrs = bau_hours + val_hours
    if total_cat_hrs > 0:
        bau_share = (bau_hours / total_cat_hrs) * 100.0
        val_share = (val_hours / total_cat_hrs) * 100.0
        insights.append(
            f"Workload split stood at **{bau_share:.1f}% BAU** vs **{val_share:.1f}% Value-Add / Continuous Improvement** ({val_hours:,.1f} hrs dedicated to non-routine transformation and governance)."
        )

    # 5. Continuous Improvement & Automation Focus (Category 6)
    ci_cat_id = next((c_id for c_id, c_name in category_names.items() if "Continuous Improvement" in c_name or "Automation" in c_name), None)
    if ci_cat_id and ci_cat_id in cat_metrics:
        ci_mix = cat_metrics[ci_cat_id].get("mix_pct", 0.0)
        ci_hrs = cat_metrics[ci_cat_id].get("hours", 0.0)
        insights.append(
            f"Continuous Improvement & Automation consumed **{ci_hrs:,.1f} hrs ({ci_mix:.1f}% of total workload)**, maintaining operational efficiency initiatives."
        )

    # 6. Close Cycle Effort Share (Categories 1, 2, 3, 4)
    if close_cycle_share is not None and close_cycle_share > 0:
        insights.append(
            f"Core Record-to-Report Close Effort (Close, Reporting, Recons & Intercompany) comprised **{close_cycle_share:.1f}%** of total capacity logged."
        )

    # 7. Comparison with Prior Period (if provided)
    if prior_period_metrics:
        prior_util = prior_period_metrics.get("utilization_pct")
        if prior_util is not None and overall_util is not None:
            delta = overall_util - prior_util
            trend_str = "increased by" if delta > 0 else "decreased by"
            insights.append(
                f"Quarter-on-Quarter utilization {trend_str} **{abs(delta):.1f} percentage points** (prior period: {prior_util:.1f}% vs current: {overall_util:.1f}%)."
            )

    # Pad or trim to ensure 5-8 solid bullet points
    if len(insights) < 5:
        avail_gap = aggregated_metrics.get("capacity_gap", 0.0)
        if avail_gap < 0:
            insights.append(
                f"Net operational deficit of **{abs(avail_gap):,.1f} hours** was absorbed across teams via overtime and unbilled hours."
            )
        else:
            insights.append(
                f"Net capacity buffer of **{avail_gap:,.1f} available hours** remained unabsorbed across the period."
            )

    return insights[:8]
