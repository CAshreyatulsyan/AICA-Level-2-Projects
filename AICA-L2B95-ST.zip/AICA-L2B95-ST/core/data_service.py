import os
from datetime import date, datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple, Set
import pandas as pd
from sqlalchemy.orm import Session
from core.db import (
    SessionLocal, User, Team, UserTeam, Category, LeaveType, Location,
    Holiday, WeeklyEntry, WeeklyLeave, WeeklyHours, Target, AutomationSaving, Setting, AuditLog
)
from core.calendar import (
    get_monday, get_sunday, get_working_days_in_week, get_working_days_list,
    format_week_label, get_fiscal_year, get_month_key, get_month_name,
    get_weeks_in_range, get_weeks_for_year, allocate_week_to_months, get_close_cycle_day
)
from core.calc import (
    LeaveRecord, HourRecord, WeekCalculationResult,
    calculate_week_utilization, aggregate_utilization, get_burnout_tier
)

def get_db_session():
    """Context manager or session getter."""
    return SessionLocal()

def get_all_categories(session: Session) -> List[Category]:
    return session.query(Category).order_by(Category.sort_order).all()

def get_all_teams(session: Session, active_only: bool = True) -> List[Team]:
    q = session.query(Team)
    if active_only:
        q = q.filter(Team.is_active == True)
    return q.order_by(Team.name).all()

def get_all_locations(session: Session) -> List[Location]:
    return session.query(Location).order_by(Location.name).all()

def get_all_leave_types(session: Session) -> List[LeaveType]:
    return session.query(LeaveType).order_by(LeaveType.id).all()

def get_all_users(session: Session, active_only: bool = True) -> List[User]:
    q = session.query(User)
    if active_only:
        q = q.filter(User.is_active == True)
    return q.order_by(User.name).all()

def get_setting(session: Session, key: str, default: str = "") -> str:
    s = session.query(Setting).filter_by(key=key).first()
    return s.value if s else default

def get_holidays_map(session: Session) -> Dict[int, Set[date]]:
    """Return {location_id: set of holiday dates}."""
    holidays = session.query(Holiday).all()
    res: Dict[int, Set[date]] = {}
    for h in holidays:
        if h.location_id not in res:
            res[h.location_id] = set()
        res[h.location_id].add(h.date)
    return res

def get_user_teams(session: Session, user_id: int) -> List[Tuple[Team, bool]]:
    """Returns list of (Team, is_primary) for the user."""
    uts = session.query(UserTeam).filter_by(user_id=user_id).all()
    res = []
    for ut in uts:
        team = session.query(Team).filter_by(id=ut.team_id).first()
        if team and team.is_active:
            res.append((team, ut.is_primary))
    return res

def fetch_and_calculate_telemetry(
    session: Session,
    year_str: str = "2026",
    fy_basis: str = "CALENDAR",
    team_ids: Optional[List[int]] = None,
    user_ids: Optional[List[int]] = None,
    location_ids: Optional[List[int]] = None,
    category_ids: Optional[List[int]] = None,
    cat_type_filter: Optional[str] = None, # 'BAU' or 'VALUE_ADD'
    start_week: Optional[date] = None,
    end_week: Optional[date] = None,
) -> Dict[str, Any]:
    """
    Core data fetcher and calculation engine for all dashboards and exports.
    Fast, relational, and fully respects all cascading filters.
    """
    std_daily_hours = float(get_setting(session, "std_daily_hours", "7.5"))
    target_util_pct = float(get_setting(session, "default_target_util", "85.0"))
    month_rule = get_setting(session, "month_allocation_rule", "PRORATE")

    # 1. Reference data caches
    all_cats = {c.id: c for c in get_all_categories(session)}
    all_teams_map = {t.id: t for t in get_all_teams(session, active_only=False)}
    all_users_map = {u.id: u for u in session.query(User).all()}
    leave_types_map = {lt.id: lt for lt in get_all_leave_types(session)}
    holidays_map = get_holidays_map(session)

    # 2. Filter users
    users_query = session.query(User).filter(User.role != "Admin")
    if user_ids:
        users_query = users_query.filter(User.id.in_(user_ids))
    if location_ids:
        users_query = users_query.filter(User.location_id.in_(location_ids))

    selected_users = users_query.all()
    selected_user_ids = {u.id for u in selected_users}

    # User primary team mapping
    user_teams_db = session.query(UserTeam).all()
    user_primary_team: Dict[int, int] = {}
    user_all_teams: Dict[int, List[int]] = {}
    for ut in user_teams_db:
        if ut.user_id not in user_all_teams:
            user_all_teams[ut.user_id] = []
        user_all_teams[ut.user_id].append(ut.team_id)
        if ut.is_primary:
            user_primary_team[ut.user_id] = ut.team_id

    # Filter by team_ids if specified
    if team_ids:
        team_id_set = set(team_ids)
        filtered_uids = set()
        for uid in selected_user_ids:
            u_teams = user_all_teams.get(uid, [])
            if any(t in team_id_set for t in u_teams):
                filtered_uids.add(uid)
        selected_user_ids = filtered_uids
        selected_users = [u for u in selected_users if u.id in selected_user_ids]

    if not selected_users:
        return {
            "aggregated": aggregate_utilization([], target_util_pct),
            "weekly_results": [],
            "raw_records": [],
            "user_summaries": [],
            "burnout_employees": [],
            "all_cats": all_cats,
            "all_teams": all_teams_map,
        }

    # 3. Determine Weeks
    if start_week and end_week:
        weeks_list = get_weeks_in_range(start_week, end_week)
    else:
        weeks_list = get_weeks_for_year(year_str, fy_basis)

    weeks_set = set(weeks_list)

    # 4. Fetch Entries
    entries = session.query(WeeklyEntry).filter(
        WeeklyEntry.user_id.in_(selected_user_ids),
        WeeklyEntry.week_start.in_(weeks_list)
    ).all()
    entry_ids = [e.id for e in entries]

    entry_map = {(e.user_id, e.week_start): e for e in entries}

    # Fetch Leaves and Hours
    leaves_by_entry: Dict[int, List[WeeklyLeave]] = {}
    if entry_ids:
        for l in session.query(WeeklyLeave).filter(WeeklyLeave.entry_id.in_(entry_ids)).all():
            if l.entry_id not in leaves_by_entry:
                leaves_by_entry[l.entry_id] = []
            leaves_by_entry[l.entry_id].append(l)

    hours_by_entry: Dict[int, List[WeeklyHours]] = {}
    if entry_ids:
        for h in session.query(WeeklyHours).filter(WeeklyHours.entry_id.in_(entry_ids)).all():
            # Check team and category filters
            if team_ids and h.team_id not in team_ids:
                continue
            if category_ids and h.category_id not in category_ids:
                continue
            if cat_type_filter:
                cat = all_cats.get(h.category_id)
                if not cat or cat.type != cat_type_filter:
                    continue

            if h.entry_id not in hours_by_entry:
                hours_by_entry[h.entry_id] = []
            hours_by_entry[h.entry_id].append(h)

    # 5. Calculate Weekly Telemetry per Employee per Week
    all_weekly_results: List[Dict[str, Any]] = []
    raw_records: List[Dict[str, Any]] = []
    user_results_map: Dict[int, List[WeekCalculationResult]] = {u.id: [] for u in selected_users}

    for u in selected_users:
        user_loc_id = u.location_id
        loc_holidays = holidays_map.get(user_loc_id, set())
        pri_t_id = user_primary_team.get(u.id)

        for w_start in weeks_list:
            entry = entry_map.get((u.id, w_start))
            entry_id = entry.id if entry else None

            # Working days in week
            w_days = get_working_days_in_week(w_start, loc_holidays)

            # Leaves
            leave_records: List[LeaveRecord] = []
            primary_leave_type_name = ""
            total_leave_days = 0.0

            if entry and entry.id in leaves_by_entry:
                for wl in leaves_by_entry[entry.id]:
                    lt = leave_types_map.get(wl.leave_type_id)
                    lt_name = lt.name if lt else "Leave"
                    is_exc = lt.excluded_from_utilization if lt else False
                    leave_records.append(LeaveRecord(
                        leave_type_name=lt_name,
                        days=wl.days,
                        is_excluded_type=is_exc
                    ))
                    total_leave_days += wl.days
                    if not primary_leave_type_name:
                        primary_leave_type_name = lt_name

            # Hours
            hour_records: List[HourRecord] = []
            if entry and entry.id in hours_by_entry:
                for wh in hours_by_entry[entry.id]:
                    c = all_cats.get(wh.category_id)
                    hour_records.append(HourRecord(
                        team_id=wh.team_id,
                        category_id=wh.category_id,
                        hours=wh.hours,
                        category_code=c.code if c else "",
                        category_name=c.name if c else "",
                        category_type=c.type if c else "BAU"
                    ))

            # Calculate Week Result
            calc_res = calculate_week_utilization(
                week_start=w_start,
                working_days=w_days,
                leaves=leave_records,
                hours_records=hour_records,
                primary_team_id=pri_t_id,
                std_daily_hours=std_daily_hours,
                join_date=u.join_date,
                exit_date=u.exit_date
            )

            user_results_map[u.id].append(calc_res)

            res_dict = {
                "user_id": u.id,
                "emp_id": u.emp_id,
                "emp_name": u.name,
                "team_id": pri_t_id,
                "team_name": all_teams_map.get(pri_t_id).name if pri_t_id and pri_t_id in all_teams_map else "Unassigned",
                "week_start": w_start,
                "week_label": format_week_label(w_start),
                "status": entry.status if entry else "Missing",
                "available_hours": calc_res.available_hours,
                "logged_hours": calc_res.logged_hours,
                "utilization_pct": calc_res.utilization_pct,
                "is_excluded": calc_res.is_excluded,
                "exclusion_reason": calc_res.exclusion_reason,
                "is_burnout": calc_res.is_burnout,
                "burnout_tier": calc_res.burnout_tier,
                "fte": calc_res.fte,
                "capacity_gap": calc_res.capacity_gap,
                "comment": entry.comment if entry else None,
                "hours_by_team": calc_res.hours_by_team,
                "available_by_team": calc_res.available_by_team,
                "hours_by_category": calc_res.hours_by_category,
                "calc_obj": calc_res
            }
            all_weekly_results.append(res_dict)

            # Build raw record for export / deep queries
            if hour_records:
                for hr in hour_records:
                    raw_records.append({
                        "emp_id": u.emp_id,
                        "emp_name": u.name,
                        "team": all_teams_map.get(hr.team_id).name if hr.team_id in all_teams_map else "Unknown",
                        "week_start": w_start,
                        "category": hr.category_name,
                        "category_type": hr.category_type,
                        "logged_hours": hr.hours,
                        "available_hours": calc_res.available_by_team.get(hr.team_id, calc_res.available_hours),
                        "leave_type": primary_leave_type_name,
                        "leave_days": total_leave_days,
                        "is_excluded": calc_res.is_excluded
                    })
            else:
                raw_records.append({
                    "emp_id": u.emp_id,
                    "emp_name": u.name,
                    "team": all_teams_map.get(pri_t_id).name if pri_t_id in all_teams_map else "Unassigned",
                    "week_start": w_start,
                    "category": "-",
                    "category_type": "-",
                    "logged_hours": 0.0,
                    "available_hours": calc_res.available_hours,
                    "leave_type": primary_leave_type_name,
                    "leave_days": total_leave_days,
                    "is_excluded": calc_res.is_excluded
                })

    # Overall Aggregated Metrics
    flat_calc_objs = [r["calc_obj"] for r in all_weekly_results]
    aggregated = aggregate_utilization(flat_calc_objs, target_util_pct)

    # User level summaries & Burnout / Attrition risk analysis
    user_summaries = []
    burnout_employees = []

    for u in selected_users:
        u_calc_list = user_results_map[u.id]
        u_agg = aggregate_utilization(u_calc_list, target_util_pct)
        pri_t_id = user_primary_team.get(u.id)
        pri_t_name = all_teams_map.get(pri_t_id).name if pri_t_id in all_teams_map else "Unassigned"

        # Find top category for this user
        top_cat_id = None
        max_c_hrs = 0.0
        for c_id, c_data in u_agg["category_metrics"].items():
            if c_data["hours"] > max_c_hrs:
                max_c_hrs = c_data["hours"]
                top_cat_id = c_id

        top_cat_name = all_cats.get(top_cat_id).name if top_cat_id and top_cat_id in all_cats else "-"

        # Peak week
        included_u_weeks = [r for r in u_calc_list if not r.is_excluded and r.utilization_pct is not None]
        peak_util = max([r.utilization_pct for r in included_u_weeks], default=0.0)
        peak_w_obj = next((r for r in included_u_weeks if r.utilization_pct == peak_util), None)
        peak_week_label = format_week_label(peak_w_obj.week_start) if peak_w_obj else "-"

        # Submission status count
        user_entries = [entry_map.get((u.id, ws)) for ws in weeks_list]
        submitted_cnt = sum(1 for e in user_entries if e and e.status == "Submitted")
        compliance_pct = round((submitted_cnt / len(weeks_list)) * 100.0, 1) if weeks_list else 100.0

        u_summary = {
            "user_id": u.id,
            "emp_id": u.emp_id,
            "name": u.name,
            "team_id": pri_t_id,
            "team": pri_t_name,
            "available_hours": u_agg["total_available_hours"],
            "logged_hours": u_agg["total_logged_hours"],
            "utilization_pct": u_agg["utilization_pct"],
            "top_category": top_cat_name,
            "burnout_weeks_count": u_agg["burnout_weeks_count"],
            "max_burnout_streak": u_agg["max_burnout_streak"],
            "peak_utilization": peak_util,
            "peak_week": peak_week_label,
            "compliance_pct": compliance_pct,
            "capacity_gap": u_agg["capacity_gap"],
            "avg_fte": u_agg["avg_fte"]
        }
        user_summaries.append(u_summary)

        if u_agg["burnout_weeks_count"] > 0:
            burnout_employees.append({
                "emp_id": u.emp_id,
                "name": u.name,
                "team": pri_t_name,
                "flagged_weeks": u_agg["burnout_weeks_count"],
                "consecutive_streak": u_agg["max_burnout_streak"],
                "peak_utilization": peak_util,
                "peak_week": peak_week_label,
                "severity": get_burnout_tier(peak_util) or "Watch",
                "top_category": top_cat_name
            })

    # Sort burnout employees by flagged weeks descending
    burnout_employees.sort(key=lambda x: (x["flagged_weeks"], x["peak_utilization"]), reverse=True)

    return {
        "aggregated": aggregated,
        "weekly_results": all_weekly_results,
        "raw_records": raw_records,
        "user_summaries": user_summaries,
        "burnout_employees": burnout_employees,
        "all_cats": all_cats,
        "all_teams": all_teams_map,
        "weeks_list": weeks_list,
        "target_util_pct": target_util_pct,
        "std_daily_hours": std_daily_hours
    }
