import os
from datetime import datetime, date
from sqlalchemy import (
    create_engine, Column, Integer, String, Float, Boolean, Date, DateTime,
    ForeignKey, Text, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker, scoped_session

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "tracker.db")

os.makedirs(DATA_DIR, exist_ok=True)

DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

SessionLocal = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))
Base = declarative_base()

# Models
class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    country = Column(String(50), nullable=False, default="India")

    users = relationship("User", back_populates="location")
    holidays = relationship("Holiday", back_populates="location", cascade="all, delete-orphan")


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    emp_id = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(String(100), nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    role = Column(String(30), nullable=False, default="Employee")  # Employee, Team Lead, Manager, Director, Admin
    password_hash = Column(String(255), nullable=False)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=True)
    join_date = Column(Date, nullable=True)
    exit_date = Column(Date, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    must_change_pw = Column(Boolean, default=False, nullable=False)

    location = relationship("Location", back_populates="users")
    user_teams = relationship("UserTeam", back_populates="user", cascade="all, delete-orphan")
    entries = relationship("WeeklyEntry", back_populates="user", cascade="all, delete-orphan")


class Team(Base):
    __tablename__ = "teams"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    lead_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    function = Column(String(100), nullable=False, default="Record to Report")
    cost_centre = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)

    user_teams = relationship("UserTeam", back_populates="team", cascade="all, delete-orphan")
    targets = relationship("Target", back_populates="team", cascade="all, delete-orphan")


class UserTeam(Base):
    __tablename__ = "user_teams"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=False)
    is_primary = Column(Boolean, default=False, nullable=False)

    user = relationship("User", back_populates="user_teams")
    team = relationship("Team", back_populates="user_teams")

    __table_args__ = (UniqueConstraint("user_id", "team_id", name="uq_user_team"),)


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(150), unique=True, nullable=False)
    type = Column(String(20), nullable=False, default="BAU")  # 'BAU' or 'VALUE_ADD'
    sort_order = Column(Integer, nullable=False)
    color = Column(String(20), nullable=False, default="#1E3A8A")
    is_active = Column(Boolean, default=True, nullable=False)

    targets = relationship("Target", back_populates="category", cascade="all, delete-orphan")


class LeaveType(Base):
    __tablename__ = "leave_types"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    excluded_from_utilization = Column(Boolean, default=False, nullable=False)
    is_system = Column(Boolean, default=True, nullable=False)


class Holiday(Base):
    __tablename__ = "holidays"
    id = Column(Integer, primary_key=True, index=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    date = Column(Date, nullable=False)
    name = Column(String(150), nullable=False)

    location = relationship("Location", back_populates="holidays")

    __table_args__ = (UniqueConstraint("location_id", "date", name="uq_location_date"),)


class WeeklyEntry(Base):
    __tablename__ = "weekly_entries"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    week_start = Column(Date, nullable=False)  # Always the Monday of the week
    status = Column(String(20), nullable=False, default="Draft")  # Draft, Submitted
    comment = Column(Text, nullable=True)
    submitted_at = Column(DateTime, nullable=True)
    locked = Column(Boolean, default=False, nullable=False)

    user = relationship("User", back_populates="entries")
    leaves = relationship("WeeklyLeave", back_populates="entry", cascade="all, delete-orphan")
    hours = relationship("WeeklyHours", back_populates="entry", cascade="all, delete-orphan")

    __table_args__ = (UniqueConstraint("user_id", "week_start", name="uq_user_week"),)


class WeeklyLeave(Base):
    __tablename__ = "weekly_leaves"
    id = Column(Integer, primary_key=True, index=True)
    entry_id = Column(Integer, ForeignKey("weekly_entries.id", ondelete="CASCADE"), nullable=False)
    leave_type_id = Column(Integer, ForeignKey("leave_types.id"), nullable=False)
    days = Column(Float, nullable=False, default=0.0)

    entry = relationship("WeeklyEntry", back_populates="leaves")
    leave_type = relationship("LeaveType")

    __table_args__ = (UniqueConstraint("entry_id", "leave_type_id", name="uq_entry_leavetype"),)


class WeeklyHours(Base):
    __tablename__ = "weekly_hours"
    id = Column(Integer, primary_key=True, index=True)
    entry_id = Column(Integer, ForeignKey("weekly_entries.id", ondelete="CASCADE"), nullable=False)
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    hours = Column(Float, nullable=False, default=0.0)

    entry = relationship("WeeklyEntry", back_populates="hours")
    team = relationship("Team")
    category = relationship("Category")

    __table_args__ = (UniqueConstraint("entry_id", "team_id", "category_id", name="uq_entry_team_cat"),)


class Target(Base):
    __tablename__ = "targets"
    id = Column(Integer, primary_key=True, index=True)
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=True)  # Null = Global target
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    target_mix_pct = Column(Float, nullable=True)
    target_util_pct = Column(Float, default=85.0, nullable=False)
    fy = Column(String(10), default="2026", nullable=False)

    team = relationship("Team", back_populates="targets")
    category = relationship("Category", back_populates="targets")


class AutomationSaving(Base):
    __tablename__ = "automation_savings"
    id = Column(Integer, primary_key=True, index=True)
    month_year = Column(String(7), nullable=False)  # 'YYYY-MM'
    team_id = Column(Integer, ForeignKey("teams.id"), nullable=True)
    hours_saved = Column(Float, nullable=False, default=0.0)
    description = Column(String(255), nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    team = relationship("Team")


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(50), primary_key=True)
    value = Column(Text, nullable=False)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=True)
    action = Column(String(50), nullable=False)
    table_name = Column(String(50), nullable=False)
    record_id = Column(String(50), nullable=True)
    old_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    ts = Column(DateTime, default=datetime.utcnow, nullable=False)


# Seeding and Initialization
DEFAULT_CATEGORIES = [
    (1, "CLOSE", "Period-End Close (Month/Quarter/Year)", "BAU", 1, "#1E3A8A"),
    (2, "REPORTING", "Financial Reporting (BPC & Group Reporting)", "BAU", 2, "#2563EB"),
    (3, "RECON", "Account Reconciliations", "BAU", 3, "#0284C7"),
    (4, "INTERCO", "Intercompany", "BAU", 4, "#0D9488"),
    (5, "AUDIT", "Audit, Control & Compliance", "BAU", 5, "#D97706"),
    (6, "CI_AUTO", "Continuous Improvement & Automation", "VALUE_ADD", 6, "#059669"),
    (7, "GOVERNANCE", "Stakeholder Management, People Mgt & Governance", "VALUE_ADD", 7, "#7C3AED"),
    (8, "ADHOC", "Ad-hoc & Special Projects", "VALUE_ADD", 8, "#EA580C"),
    (9, "FPNA", "Planning & Forecasting", "BAU", 9, "#4F46E5"),
]

DEFAULT_LEAVE_TYPES = [
    ("Casual / Earned / Sick Leave", False, True),
    ("Comp-off", False, True),
    ("Public Holiday", False, True),
    ("Full-week Leave", True, True),
    ("Maternity / Paternity Leave", True, True),
    ("Sabbatical", True, True),
    ("Long-term Medical Leave", True, True),
]

DEFAULT_LOCATIONS = [
    ("India - Gurugram", "India"),
    ("India - Kolkata", "India"),
    ("UK - London", "United Kingdom"),
    ("US - New York", "United States"),
]

DEFAULT_SETTINGS = {
    "std_daily_hours": "7.5",
    "default_target_util": "85.0",
    "threshold_under": "70.0",
    "threshold_below_target": "85.0",
    "threshold_optimal": "100.0",
    "burnout_threshold": "100.0",
    "burnout_watch": "110.0",
    "burnout_high": "120.0",
    "fy_basis": "CALENDAR",  # CALENDAR (Jan-Dec) or FINANCIAL (Apr-Mar)
    "month_allocation_rule": "PRORATE",  # PRORATE or ISO_THURSDAY
    "auto_lock_days": "30",
}

def init_db():
    """Create database tables and seed baseline reference data if not present."""
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        # Locations
        for loc_name, country in DEFAULT_LOCATIONS:
            if not session.query(Location).filter_by(name=loc_name).first():
                session.add(Location(name=loc_name, country=country))
        session.commit()

        # Categories
        for sort_order, code, name, cat_type, order, color in DEFAULT_CATEGORIES:
            existing = session.query(Category).filter_by(code=code).first()
            if not existing:
                session.add(Category(
                    code=code,
                    name=name,
                    type=cat_type,
                    sort_order=sort_order,
                    color=color,
                    is_active=True
                ))
        session.commit()

        # Leave Types
        for name, excluded, is_system in DEFAULT_LEAVE_TYPES:
            existing = session.query(LeaveType).filter_by(name=name).first()
            if not existing:
                session.add(LeaveType(
                    name=name,
                    excluded_from_utilization=excluded,
                    is_system=is_system
                ))
        session.commit()

        # Settings
        for key, val in DEFAULT_SETTINGS.items():
            existing = session.query(Setting).filter_by(key=key).first()
            if not existing:
                session.add(Setting(key=key, value=val))
        session.commit()

        # Default Admin User
        admin_user = session.query(User).filter_by(emp_id="EMP001").first()
        if not admin_user:
            from core.auth import hash_password
            gurugram = session.query(Location).filter_by(name="India - Gurugram").first()
            admin = User(
                emp_id="EMP001",
                name="System Administrator",
                email="admin@finance.org",
                role="Admin",
                password_hash=hash_password("admin123"),
                location_id=gurugram.id if gurugram else None,
                join_date=date(2024, 1, 1),
                is_active=True,
                must_change_pw=False
            )
            session.add(admin)
            session.commit()

        # Seed standard holidays for 2025 and 2026 for India
        loc_ggn = session.query(Location).filter_by(name="India - Gurugram").first()
        loc_kol = session.query(Location).filter_by(name="India - Kolkata").first()
        if loc_ggn:
            standard_holidays_2026 = [
                (date(2026, 1, 26), "Republic Day"),
                (date(2026, 3, 4), "Holi"),
                (date(2026, 4, 3), "Good Friday"),
                (date(2026, 5, 1), "May Day"),
                (date(2026, 8, 15), "Independence Day"),
                (date(2026, 10, 2), "Gandhi Jayanti"),
                (date(2026, 10, 20), "Dussehra"),
                (date(2026, 11, 8), "Diwali"),
                (date(2026, 12, 25), "Christmas Day"),
            ]
            for h_date, h_name in standard_holidays_2026:
                if not session.query(Holiday).filter_by(location_id=loc_ggn.id, date=h_date).first():
                    session.add(Holiday(location_id=loc_ggn.id, date=h_date, name=h_name))
                if loc_kol and not session.query(Holiday).filter_by(location_id=loc_kol.id, date=h_date).first():
                    session.add(Holiday(location_id=loc_kol.id, date=h_date, name=h_name))
            session.commit()

    finally:
        session.close()

def log_audit(session, user_id, action, table_name, record_id=None, old_val=None, new_val=None):
    """Utility to log actions to audit_log table."""
    try:
        audit = AuditLog(
            user_id=user_id,
            action=action,
            table_name=table_name,
            record_id=str(record_id) if record_id else None,
            old_value=str(old_val) if old_val is not None else None,
            new_value=str(new_val) if new_val is not None else None,
            ts=datetime.utcnow()
        )
        session.add(audit)
    except Exception as e:
        print(f"Audit log failed: {e}")
