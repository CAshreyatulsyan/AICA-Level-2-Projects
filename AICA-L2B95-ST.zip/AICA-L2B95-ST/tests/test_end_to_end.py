import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datetime import date
from core.db import init_db, SessionLocal, User, Setting
from core.seed_data import seed_demo_data
from core.data_service import fetch_and_calculate_telemetry
from core.export_excel import create_utilization_excel_workbook
from core.export_pptx import create_director_presentation
from core.insights import generate_insights
import pandas as pd

def test_full_pipeline():
    print("1. Initializing DB and Seeding...")
    init_db()
    seed_res = seed_demo_data()
    print("Seed status:", seed_res["status"])

    session = SessionLocal()
    try:
        print("2. Fetching Telemetry for 2026...")
        telemetry = fetch_and_calculate_telemetry(
            session=session,
            year_str="2026",
            fy_basis="CALENDAR"
        )
        agg = telemetry["aggregated"]
        print(f"Overall Util: {agg['utilization_pct']}% across {agg['total_logged_hours']} logged hours")
        assert agg["total_logged_hours"] > 0
        assert agg["total_available_hours"] > 0

        print("3. Generating Rule-Based Insights...")
        all_cats = telemetry["all_cats"]
        all_teams = telemetry["all_teams"]
        insights = generate_insights(
            aggregated_metrics=agg,
            team_names={t.id: t.name for t in all_teams.values()},
            category_names={c.id: c.name for c in all_cats.values()},
            category_types={c.id: c.type for c in all_cats.values()},
            burnout_details=telemetry["burnout_employees"],
            close_cycle_share=45.0
        )
        print(f"Generated {len(insights)} insights:")
        for ins in insights:
            print("  •", ins)
        assert len(insights) >= 5

        print("4. Testing Excel 8-Sheet Export...")
        excel_io = create_utilization_excel_workbook(
            summary_data=agg,
            raw_records=telemetry["raw_records"],
            employee_weekly_df=pd.DataFrame([{"Employee": "Test", "W01": 0.85}]),
            employee_monthly_df=pd.DataFrame([{"Employee": "Test", "Jan": 0.85}]),
            employee_yearly_df=pd.DataFrame([{"Employee": "Test", "Util": 0.85}]),
            team_cat_matrix_df=pd.DataFrame([{"Team": "R2R", "CLOSE": 100.0}]),
            cat_analysis_df=pd.DataFrame([{"Category": "CLOSE", "Mix": 0.30}]),
            leave_exclusions_df=pd.DataFrame([{"Employee": "Test", "Reason": "Maternity"}]),
            exceptions_df=pd.DataFrame([{"Employee": "Test", "Type": "Burnout"}]),
            filters_info={"Year": "2026", "Scope": "All"}
        )
        excel_bytes = excel_io.getvalue()
        assert len(excel_bytes) > 5000
        print(f"Excel workbook generated successfully ({len(excel_bytes)} bytes)")

        print("5. Testing PowerPoint Export...")
        pptx_io = create_director_presentation(
            summary_data=agg,
            filters_info={"Year": "2026", "Scope": "All"},
            insights_list=insights,
            team_data=[{"name": "R2R", "logged": 500.0, "available": 500.0, "utilization_pct": 100.0}],
            cat_data=[{"name": "Period-End Close", "type": "BAU", "hours": 300.0, "mix_pct": 30.0, "util_pct": 30.0}],
            burnout_data=telemetry["burnout_employees"]
        )
        pptx_bytes = pptx_io.getvalue()
        assert len(pptx_bytes) > 20000
        print(f"PowerPoint deck generated successfully ({len(pptx_bytes)} bytes)")

        print("All end-to-end integration tests PASSED!")
    finally:
        session.close()

if __name__ == "__main__":
    test_full_pipeline()
