import pytest
from datetime import date, timedelta
from core.calc import (
    LeaveRecord,
    HourRecord,
    calculate_week_utilization,
    aggregate_utilization,
    get_burnout_tier,
    get_utilization_status,
)
from core.calendar import (
    allocate_week_to_months,
    get_fiscal_year,
    get_working_days_in_week,
)

def test_normal_week():
    """5 working days, 0 leave, 37.5 hrs logged -> 100% util, 0 capacity gap, 1.0 FTE"""
    week_start = date(2026, 1, 5)  # Monday
    leaves = []
    hours = [HourRecord(team_id=1, category_id=1, hours=37.5)]

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours,
        std_daily_hours=7.5
    )

    assert not res.is_excluded
    assert res.available_hours == 37.5
    assert res.logged_hours == 37.5
    assert res.utilization_pct == 100.0
    assert res.fte == 1.0
    assert res.capacity_gap == 0.0
    assert not res.is_burnout

def test_worked_example_partial_leave_and_overload():
    """
    Prompt worked example:
    Employee with 5 working days, 1 casual leave day, logs 41 hours
    -> available = 4 * 7.5 = 30 hrs, utilization = 136.7%, Critical burnout flag, no restriction.
    """
    week_start = date(2026, 1, 12)
    leaves = [LeaveRecord(leave_type_name="Casual Leave", days=1.0, is_excluded_type=False)]
    hours = [
        HourRecord(team_id=1, category_id=1, hours=25.0),
        HourRecord(team_id=1, category_id=2, hours=16.0),
    ]

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours,
        std_daily_hours=7.5
    )

    assert not res.is_excluded
    assert res.working_days == 5
    assert res.total_leave_days == 1.0
    assert res.available_hours == 30.0
    assert res.logged_hours == 41.0
    assert res.utilization_pct == 136.7
    assert res.is_burnout is True
    assert res.burnout_tier == "Critical"
    assert res.capacity_gap == -11.0  # Overload

def test_full_week_leave_exclusion():
    """Full-week leave must drop the week completely from available hours and utilization."""
    week_start = date(2026, 1, 19)
    leaves = [LeaveRecord(leave_type_name="Full-week Leave", days=5.0, is_excluded_type=True)]
    hours = []

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours,
        std_daily_hours=7.5,
        force_full_week_leave=True
    )

    assert res.is_excluded is True
    assert res.exclusion_reason == "Full-week Leave"
    assert res.available_hours == 0.0
    assert res.utilization_pct is None
    assert not res.is_burnout

def test_maternity_leave_across_multiple_weeks():
    """Maternity leave week must be marked excluded with reason."""
    week_start = date(2026, 2, 2)
    leaves = [LeaveRecord(leave_type_name="Maternity / Paternity Leave", days=5.0, is_excluded_type=True)]
    hours = []

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours
    )

    assert res.is_excluded is True
    assert "Maternity" in res.exclusion_reason
    assert res.available_hours == 0.0

def test_holiday_week():
    """Week with 2 public holidays -> 3 working days -> 22.5 available hours."""
    week_start = date(2026, 10, 19)  # Monday
    # 2 holidays in this week
    leaves = []
    hours = [HourRecord(team_id=1, category_id=3, hours=22.5)]

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=3,
        leaves=leaves,
        hours_records=hours,
        std_daily_hours=7.5
    )

    assert res.available_hours == 22.5
    assert res.logged_hours == 22.5
    assert res.utilization_pct == 100.0

def test_burnout_tiers():
    """Test Watch (100-110%), High (110-120%), Critical (>120%)"""
    assert get_burnout_tier(99.0) is None
    assert get_burnout_tier(100.0) is None
    assert get_burnout_tier(105.0) == "Watch"
    assert get_burnout_tier(110.0) == "Watch"
    assert get_burnout_tier(115.0) == "High"
    assert get_burnout_tier(120.0) == "High"
    assert get_burnout_tier(121.0) == "Critical"
    assert get_burnout_tier(150.0) == "Critical"

def test_straddling_week_prorate():
    """
    Week starting Monday 2026-03-30:
    Mon 30 Mar, Tue 31 Mar -> 2 days in March.
    Wed 01 Apr, Thu 02 Apr, Fri 03 Apr -> 3 days in April.
    Logged: 40 hrs, Available: 37.5 hrs.
    March share: 2/5 (40%) -> Logged: 16, Available: 15.
    April share: 3/5 (60%) -> Logged: 24, Available: 22.5.
    """
    week_start = date(2026, 3, 30)
    alloc = allocate_week_to_months(week_start, logged_hours=40.0, available_hours=37.5, rule="PRORATE")

    assert "2026-03" in alloc
    assert "2026-04" in alloc
    assert alloc["2026-03"]["logged"] == 16.0
    assert alloc["2026-03"]["available"] == 15.0
    assert alloc["2026-04"]["logged"] == 24.0
    assert alloc["2026-04"]["available"] == 22.5

def test_straddling_week_iso_thursday():
    """ISO Thursday rule assigns the entire week to the month containing Thursday."""
    week_start = date(2026, 3, 30)  # Thursday is April 2
    alloc = allocate_week_to_months(week_start, logged_hours=40.0, available_hours=37.5, rule="ISO_THURSDAY")

    assert "2026-04" in alloc
    assert "2026-03" not in alloc
    assert alloc["2026-04"]["logged"] == 40.0

def test_weighted_aggregation_vs_naive_average():
    """
    Aggregation MUST be hours-weighted, never average of percentages.
    Week 1: 10 hrs logged on 10 hrs available = 100%
    Week 2: 50 hrs logged on 25 hrs available = 200%
    Naive average: (100 + 200) / 2 = 150.0%
    Weighted average: (10 + 50) / (10 + 25) = 60 / 35 = 171.4%
    """
    w1 = calculate_week_utilization(
        week_start=date(2026, 1, 5),
        working_days=5,
        leaves=[LeaveRecord(leave_type_name="Casual", days=3.666666, is_excluded_type=False)],
        hours_records=[HourRecord(team_id=1, category_id=1, hours=10.0)],
        std_daily_hours=7.5
    )
    # Override available hours directly for pure mathematical precision test
    w1.available_hours = 10.0
    w1.logged_hours = 10.0
    w1.utilization_pct = 100.0

    w2 = calculate_week_utilization(
        week_start=date(2026, 1, 12),
        working_days=5,
        leaves=[],
        hours_records=[HourRecord(team_id=1, category_id=1, hours=50.0)],
        std_daily_hours=7.5
    )
    w2.available_hours = 25.0
    w2.logged_hours = 50.0
    w2.utilization_pct = 200.0

    agg = aggregate_utilization([w1, w2])
    assert agg["total_logged_hours"] == 60.0
    assert agg["total_available_hours"] == 35.0
    assert agg["utilization_pct"] == 171.4
    assert agg["utilization_pct"] != 150.0  # Not naive average

def test_zero_available_edge_case():
    """When an employee takes 5 days of regular leave in a 5-day week, available = 0 and is_excluded."""
    week_start = date(2026, 5, 4)
    leaves = [LeaveRecord(leave_type_name="Sick Leave", days=5.0, is_excluded_type=False)]
    hours = []

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours
    )

    assert res.is_excluded is True
    assert res.available_hours == 0.0

def test_multi_team_split():
    """
    Employee logs 30 hours in Team 1 and 10 hours in Team 2 out of 40 total logged hours.
    Available hours = 37.5.
    Team 1 available attribution = 37.5 * (30/40) = 28.12 hrs.
    Team 2 available attribution = 37.5 * (10/40) = 9.38 hrs.
    """
    week_start = date(2026, 6, 1)
    leaves = []
    hours = [
        HourRecord(team_id=1, category_id=1, hours=30.0),
        HourRecord(team_id=2, category_id=2, hours=10.0),
    ]

    res = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=leaves,
        hours_records=hours,
        std_daily_hours=7.5
    )

    assert res.hours_by_team[1] == 30.0
    assert res.hours_by_team[2] == 10.0
    assert round(res.available_by_team[1], 2) == 28.12
    assert round(res.available_by_team[2], 2) == 9.38
    assert round(res.available_by_team[1] + res.available_by_team[2], 2) == 37.5

def test_fiscal_year_calendar_vs_financial():
    """Calendar year vs Financial year (Apr-Mar)"""
    d_jan = date(2026, 1, 15)
    d_may = date(2025, 5, 20)

    # Calendar
    assert get_fiscal_year(d_jan, "CALENDAR") == "2026"
    assert get_fiscal_year(d_may, "CALENDAR") == "2025"

    # Financial (Apr to Mar)
    # Jan 2026 is in FY2025-26
    assert get_fiscal_year(d_jan, "FINANCIAL") == "FY2025-26"
    # May 2025 is in FY2025-26
    assert get_fiscal_year(d_may, "FINANCIAL") == "FY2025-26"
    # Apr 2026 is in FY2026-27
    assert get_fiscal_year(date(2026, 4, 1), "FINANCIAL") == "FY2026-27"

def test_join_and_exit_tenure_exclusion():
    """Weeks outside employee join and exit dates must be excluded."""
    week_start = date(2026, 1, 5)  # Ends 2026-01-11
    # Joined on 2026-02-01
    res_before = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=[],
        hours_records=[],
        join_date=date(2026, 2, 1)
    )
    assert res_before.is_excluded is True
    assert "Joining" in res_before.exclusion_reason

    # Exited on 2025-12-31
    res_after = calculate_week_utilization(
        week_start=week_start,
        working_days=5,
        leaves=[],
        hours_records=[],
        exit_date=date(2025, 12, 31)
    )
    assert res_after.is_excluded is True
    assert "Exit" in res_after.exclusion_reason
